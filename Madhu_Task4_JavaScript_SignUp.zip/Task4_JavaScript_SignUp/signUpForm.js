function setError(id,error){

    let element=document.getElementById(id);
    element.getElementsByClassName("formerror")[0].innerHTML=error;
}
function clearErrors(){
    let errors=document.getElementsByClassName("formerror");
    for(let item of errors){
        item.innerHTML="";
    }
}
function validateForm(){
    event.preventDefault();
    clearErrors();
    console.log("hello")
   
   let fname=document.forms['myForm']['fName'].value;
   let lname=document.forms['myForm']['lName'].value;
   let pemail=document.forms['myForm']['pemail'].value;
   let phoneNo=document.forms['myForm']['phoneNo'].value;
   let country=document.forms['myForm']['country'].value;
   let pass=document.forms['myForm']['pass'].value;


   if(fname.length===0 && lname.length===0 && pemail.length===0 && phoneNo.length===0 && country==='Default' && pass.length===0){
    alert("Please Enter The Details");
   }
   var letters = /^[A-Za-z]+$/;
   console.log(fname);
   if(fname.length === 0 )
   {
    setError("fName", "*FirstName Cannot Be Empty");
   }
   else if(!(fname.match(letters))){
    setError("fName", "*Enter alphabet characters only");
   }
   else if(fname.length<6 && fname.length>15)
   {
    setError("fName", "*Length is too short or too Long");
   }

   
   if(lname.length === 0 )
   {
    setError("lName", "*LastName Cannot Be Empty");
   }
   else if(!(lname.match(letters))){
    setError("lName", "*Enter alphabet characters only");
   }
   else if(lname.length<6 && lname.length>15)
   {
    setError("lName", "*Length is too short or too Long");
   }

   
   var emailPattern = /^[\w._-]+[+]?[\w._-]+@[\w.-]+\.[a-zA-Z]{2,6}$/;  ///^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
   if(!(emailPattern.test(pemail)) || (pemail.length === 0 )){
    setError("pemail", "*Invalid Email or Email is Empty");
   }

   else if(pemail.length>15)
   {
    setError("pemail", "*Email is too Long");
   }
  

  
   var phonePattern=/^[6-9]\d{9}$/;
   console.log(phoneNo);
   if((phoneNo.length === 0) || !(phonePattern.test(phoneNo)) )
   {
    setError("phoneNo", "*Invalid Ph-Number or Ph-Number is Empty");
   }
   if(country == "Default"){
    setError("phoneNo", "*Select your country from the list");
   }

  
//    let passPattern=/^([a-zA-Z].*[0-9])|([0-9].*[a-zA-Z])$/;

//At least 1 uppercase character.  At least 1 lowercase character. At least 1 digit. At least 1 special character.
  
   console.log(pass);
   if(pass.length === 0 )
   {
    setError("pass", "*Password Cannot Be Empty");
   }
   else if (!(pass.match(/[a-z]/g) && pass.match(
    /[A-Z]/g) && pass.match(
    /[0-9]/g) && pass.match(
    /[^a-zA-Z\d]/g))){
        setError("pass", "*Password is invalid");
    }
   else if(!(pass.length>6) || !(pass.length<15)){
    setError("pass", "*Password length is invalid");
   }
   
}