package com.zkteco.task.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Result;
import com.zkteco.task.entity.User;
import com.zkteco.task.exception.ResourceNotFoundException;
import com.zkteco.task.repository.UserRepository;

import jakarta.validation.Valid;

@Service
public class UserService {
	
	@Autowired
	private UserRepository repository;


	public Result saveUser(@Valid User user) {
		
		Optional<User> userDbData = repository.findById(user.getUserId());
		User userDbData1 =repository.findByUserEmailId(user.getUserEmailId());
		User userDbData2 = repository.findByphoneNumber(user.getPhoneNumber());
		
		String firstName=user.getFirstName();
		String email=user.getUserEmailId();
		String phone=user.getPhoneNumber();
		String password=user.getPassword();
		
		if(user.getUserId().length()!=0)
		{
			if (user.getUserId().length() >= 4)
			{
				Result result = new Result("Invalid: User Id Length is Big", "Check ID Length");
				return result;
			}
		}
		else {
			Result result = new Result("User Id cannot be empty", "Check ID");
			return result;
		}
		
		if(!firstName.isEmpty())
		{
			if(firstName.length()>=6)
			{
				Result result = new Result("User Name Too Lengthy", "check User length");
				return result;
			}
		}
		else {
			Result result = new Result("Employee Name cannot be empty", "");
			return result;
		}
		
		if(user.getLastName().length()>=6)
		{
			return new Result("User Last Name is Too Lengthy", "check length");
		}
		if(user.getGender().length()>2)
		{
			return new Result("Enter gender in 1 character", "check length");
		}
		
		if(!email.isEmpty())
		{
			if(!email.contains(".") && !email.contains("@")){
				Result result = new Result("Email Should contain Dot '.' and '@' Symbol", "Invalid");
				return result;
			}
			else if(!email.contains("@"))
			{
				Result result = new Result("Email Should contain '@' Symbol", "");
				return result;
			}
			else if (!email.contains(".")) {
				Result result = new Result("Email Should contain Dot '.'", "");
				return result;
			}
		}
		else {
			Result result = new Result("Email cannot be empty", "");
			return result;
		}
		
		if(!phone.isEmpty())
		{
			String[] arr=phone.split("-", 2);
			if(phone.length()>14)
			{
				Result result = new Result("Invalid Phone Number", "");
				return result;
			}
			else if (!phone.contains("-") && !phone.contains("+")) {
				Result result = new Result("Invalid Phone Number '+' and '-' is missing", "");
				return result;
			}
			else if(!phone.contains("+")) {
				Result result = new Result("Invalid Phone Number '+' is missing", "");
				return result;
			}
			else if(!phone.contains("-")) {
				Result result = new Result("Invalid Phone Number '-' is missing", "");
				return result;
			}
			
			if(!(arr[1].length()==10))
			{
				Result result = new Result("Phone number is incorrect", "");
				return result;
			}
			else if (!arr[0].contains("+91") && !(arr[0].length()==3)) {
				Result result = new Result("Country code is Wrong", "");
				return result;
			}
		}
		else {
			Result result = new Result("Phone Number cannot be empty", "");
			return result;
		}
		
		if(!password.isEmpty())
		{
		    if(!(password.matches("(([a-zA-Z].*[0-9])|([0-9].*[a-zA-Z]))")) )
			{
				return new Result("Password has invalid characters", "");
			}
			if(!(password.length()>=8 &&  password.length()<=20))
			{
				return new Result("Password length is invalid", "");
			}
			else if(!(password.matches(".*[0-9]{2,}.*"))){
				return new Result("Password should consists of atleast two Digits", "Invalid");
			}
			else if(!(password.matches(".*[A-Z]{1,}.*")))
			{
				return new Result("Password should consists of atleast One Upper Case", "Invalid");
			}
		}
		else {
			return new Result("Password cannot be empty", "");
		}

		if (userDbData.isEmpty()) {
			if (userDbData1==null) {
				if (userDbData2==null) {
					User userResponse = repository.save(user);
					Result result = new Result("User Data Saved in the DataBase", userResponse);
					return result;
				}
				return new Result("Phone Number is already registered", "");
			}
			return new Result("Email Address is already registered", "");
		}
		return new Result("This Employee Is Already Registered", "");

	}


	public List<User> fetchAllData() {
		return repository.findAll();
	}


	public User fetchById(String userId) throws ResourceNotFoundException {
		User user=repository.findById(userId).orElseThrow(()->new ResourceNotFoundException("User Not found for this is id "+userId));
		return user;
	}


	public User fetchByEmail(String userEmailId) throws ResourceNotFoundException {
		User user=repository.findByUserEmailId(userEmailId);
		if(user==null)
		{
			throw new ResourceNotFoundException("User Not found for this is emailId "+userEmailId);
		}
		return user;
	}


	public User fetchByPhone(String phoneNumber) throws ResourceNotFoundException {
		
		List<User> userDb=fetchAllData();
		String[] phone=phoneNumber.split("-", 2);
		User user2=null;
		for (User user : userDb) {
			if((user.getPhoneNumber().split("-", 2)[1].equals(phone[1])))
			{
				user2=user;
			}
			else continue;
		}
		return user2;
	}


	public User deleteById(String userId) throws ResourceNotFoundException {
		User user=fetchById(userId);
		repository.deleteById(userId);
		return user;
		
	}


	public User updateById(String userId, User user) throws ResourceNotFoundException {
		User userdb = repository.findById(userId).orElseThrow(()->new ResourceNotFoundException("User Not found for this is :"+userId));;

		if (Objects.nonNull(user.getFirstName()) && !"".equalsIgnoreCase(user.getFirstName())) // if null and empty data then skip that data
		{
			userdb.setFirstName(user.getFirstName());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(user.getLastName()) && !"".equalsIgnoreCase(user.getLastName())) 
		{
			userdb.setLastName(user.getLastName());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(user.getGender()) && !"".equalsIgnoreCase(user.getGender())) 
		{
			userdb.setGender(user.getGender());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(user.getUserEmailId()) && !"".equalsIgnoreCase(user.getUserEmailId())) 
		{
			userdb.setUserEmailId(user.getUserEmailId());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(user.getPhoneNumber())) {
			userdb.setPhoneNumber(user.getPhoneNumber());
		}
		if (Objects.nonNull(user.getDateOfBirth()) && !"".equalsIgnoreCase(user.getDateOfBirth())) {
			userdb.setDateOfBirth(user.getDateOfBirth());
		}
		if (Objects.nonNull(user.getPassword()) && !"".equalsIgnoreCase(user.getPassword())) {
			userdb.setPassword(user.getPassword());
		}
		if (Objects.nonNull(user.getCreateDate()) && !"".equalsIgnoreCase(user.getCreateDate())) {
			userdb.setCreateDate(user.getCreateDate());
		}
		if (Objects.nonNull(user.getUpdateDate()) && !"".equalsIgnoreCase(user.getUpdateDate())) {
			userdb.setUpdateDate(user.getUpdateDate());
		}
		return repository.save(userdb);
	}



	public List<User> saveAllData(@Valid List<User> user) {
		return repository.saveAll(user);
	}



	public List<User> fetchByDate(String fromDate, String toDate) throws ResourceNotFoundException {
		
//		int from=Integer.parseInt(fromDate);
//		int to=Integer.parseInt(toDate);
//		List<User> userDb=repository.findAll();
//		List<User> user2=new ArrayList<>();
//		for (User userData : userDb) {
//			String[] str=userData.getCreateDate().split("/");
//			int val=Integer.parseInt(str[0]);
//			if((val>=from) && (val<=to))
//			{
//				user2.add(userData);
//			}
//		}
//		return  user2;
		if((LocalDate.parse(fromDate)).isAfter(LocalDate.parse(toDate)))
		{
			throw new ResourceNotFoundException("Start Date Should be After End date");
		}
		List<User> userDb=repository.findAll();
		List<User> userDataList=userDb.stream().filter((userData)->(LocalDate.parse(userData.getCreateDate()).isAfter(LocalDate.parse(fromDate)))
				&& (LocalDate.parse(userData.getCreateDate()).isBefore(LocalDate.parse(toDate)))).collect(Collectors.toList());
		return userDataList;
				
		
	}
		
		

}
