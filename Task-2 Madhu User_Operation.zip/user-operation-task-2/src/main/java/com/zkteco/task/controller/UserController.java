package com.zkteco.task.controller;


import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.task.entity.Result;
import com.zkteco.task.entity.User;
import com.zkteco.task.exception.ResourceNotFoundException;
import com.zkteco.task.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService service;

	//LOGGERS IMPLEMENTATION
		private final Logger logger=LoggerFactory.getLogger(UserController.class);
		
//////////////////////Saving data in DB(Save API)//////////

	@PostMapping("/save")
	public Result saveUser(@Valid @RequestBody User user) {
		logger.info("Inside save User Method");
		return service.saveUser(user);
	}

	@PostMapping("/save/batch")
	public List<User> saveMultipleData(@Valid @RequestBody List<User> user) {
		return service.saveAllData(user);
	}

//////////////Fetching data from DB/////////////////

	@GetMapping("/get/all")
	public List<User> fetchAllData() {
		logger.info("Inside Fetch User Method");
		return service.fetchAllData();
	}

/////////////////////////////Fetching Data by ID and email and phonenumber//////////////////

	@GetMapping("/get/{id}")
	public User fetchById(@PathVariable(value = "id") String userId) throws ResourceNotFoundException {
		logger.info("Inside FetchBy ID User Method");
		return service.fetchById(userId);
	}

	@GetMapping("/get/userEmailId")
	public User fetchByEmail(@RequestParam String userEmailId) throws ResourceNotFoundException {
		logger.info("Inside FetchBy EmailId User Method");
		return service.fetchByEmail(userEmailId);
	}
	
	@GetMapping("/get/phoneNumber")
	public User fetchByPhone(@RequestParam String phoneNumber) throws ResourceNotFoundException {
		logger.info("Inside FetchBy phone number User Method");
		return service.fetchByPhone(phoneNumber);
	}
	
	@GetMapping("/get/{fromDate}/{toDate}")
	public List<User> fetchByDate(@PathVariable(value = "fromDate") String fromDate,@PathVariable(value = "toDate") String toDate) throws ResourceNotFoundException {
		logger.info("Inside FetchBy Date User Method");
		return service.fetchByDate(fromDate,toDate);
	}
	
/////////////////////////////Deleting Data by ID/////////////////

	@DeleteMapping("/delete/{id}")
	public String deleteById(@PathVariable("id") String userId) throws ResourceNotFoundException {
		logger.info("Inside Delete by ID Method");
		User user=service.deleteById(userId);
		return "Data Deleted Sucessufully Of the User :"+user.getFirstName();
	}

////////////////////////////Updating Data by ID///////////////////

	@PutMapping("/update/{id}")
	public User updateById(@PathVariable(value = "id") String userId, @RequestBody User user) throws ResourceNotFoundException {
		logger.info("Inside Update By ID User Method");
		return service.updateById(userId, user);
	}

}
