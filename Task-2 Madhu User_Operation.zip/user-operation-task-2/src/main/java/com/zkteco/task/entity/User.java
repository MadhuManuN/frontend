package com.zkteco.task.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "User_Data")
public class User {

	@Id
	@Column(name = "User_Id")
	private String userId;
	
	@Column(name = "First_Name")
	@Size(max = 50,message = "Minimum Characters allowed is 50")
	private String firstName;
	
	@Column(name = "Last_Name")
	@Size(max = 50,message = "Minimum Characters allowed is 50")
	private String lastName;
	
	@Column(name = "Gender")
	@Size(max = 1,message = "There should be only one character")
	private String gender;
	
	@Column(name = "Email_Id",nullable = false)
	private String userEmailId;
	
	@Column(name = "Phone_Number",nullable = false)
	private String phoneNumber;
	
	@Column(name = "Password")
	private String password;
	
	@Column(name = "D_O_B")
	private String dateOfBirth;
	
	@Column(name = "Profile_Photo")
	private Boolean profilePhoto;
	
	@Column(name = "Created_Date")
	private String createDate;
	
	@Column(name = "Updated_Date")
	private String updateDate;
	
	
}
