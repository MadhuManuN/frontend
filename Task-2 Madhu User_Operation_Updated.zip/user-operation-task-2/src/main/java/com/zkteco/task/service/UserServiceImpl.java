package com.zkteco.task.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Result;
import com.zkteco.task.entity.User;
import com.zkteco.task.entity.UserDto;
import com.zkteco.task.exception.ResourceNotFoundException;
import com.zkteco.task.repository.UserRepository;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Null;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository repository;

	public Result validationMandatory(User user) {
		String firstName = user.getFirstName();
		String email = user.getUserEmailId();
		String phone = user.getPhoneNumber();
		String password = user.getPassword();
		if (!firstName.isEmpty()) {
			if (firstName.length() >= 10) {
				return new Result("E100","User Name Too Lengthy", "");
			}
		} else {
			return new Result("E100","Employee Name cannot be empty", "");
		}
		if (user.getLastName().length() >= 6) {
			return new Result("E100","User Last Name is Too Lengthy", "check length");
		}
		if (user.getGender().length() > 2) {
			return new Result("E100","Enter gender in 1 character", "check length");
		}
		if (!email.isEmpty()) {
			if (!email.contains(".") && !email.contains("@")) {
				Result result = new Result("E100","Email Should contain Dot '.' and '@' Symbol", "Invalid");
				return result;
			} else if (!email.contains("@")) {
				Result result = new Result("E100","Email Should contain '@' Symbol", "");
				return result;
			} else if (!email.contains(".")) {
				Result result = new Result("E100","Email Should contain Dot '.'", "");
				return result;
			}
		} else {
			Result result = new Result("E100","Email cannot be empty", "");
			return result;
		}

		if (!phone.isEmpty()) {
			String[] arr = phone.split("-", 2);
			if (phone.length() > 14) {
				Result result = new Result("E100","Invalid Phone Number", "");
				return result;
			} else if (!phone.contains("-") && !phone.contains("+")) {
				Result result = new Result("E100","Invalid Phone Number '+' and '-' is missing", "");
				return result;
			} else if (!phone.contains("+")) {
				Result result = new Result("E100","Invalid Phone Number '+' is missing", "");
				return result;
			} else if (!phone.contains("-")) {
				Result result = new Result("E100","Invalid Phone Number '-' is missing", "");
				return result;
			}

			if (!(arr[1].length() == 10)) {
				Result result = new Result("E100","Phone number is incorrect", "");
				return result;
			} else if (!arr[0].contains("+91") && !(arr[0].length() == 3)) {
				Result result = new Result("E100","Country code is Wrong", "");
				return result;
			}
		} else {
			Result result = new Result("E100","Phone Number cannot be empty", "");
			return result;
		}

		if (!password.isEmpty()) {
			if (!(password.matches("(([a-zA-Z].*[0-9])|([0-9].*[a-zA-Z]))"))) {
				return new Result("E100","Password has invalid characters", "");
			}
			if (!(password.length() >= 8 && password.length() <= 20)) {
				return new Result("E100","Password length is invalid", "");
			} else if (!(password.matches(".*[0-9]{2,}.*"))) {
				return new Result("E100","Password should consists of atleast two Digits", "Invalid");
			} else if (!(password.matches(".*[A-Z]{1,}.*"))) {
				return new Result("E100","Password should consists of atleast One Upper Case", "Invalid");
			}
		} else {
			return new Result("E100","Password cannot be empty", "");
		}
		return null;

	}

	public Result validation(User user) {
		Optional<User> userDbData = repository.findById(user.getUserId());
		User userDbData1 = repository.findByUserEmailId(user.getUserEmailId());
		User userDbData2 = repository.findByphoneNumber(user.getPhoneNumber());
		User userResponse = new User();

		if (user.getUserId().length() != 0) {
			if (user.getUserId().length() >= 4) {
				Result result = new Result("E100","Invalid: User Id Length is Big", "Check ID Length");
				return result;
			}
		} else {
			Result result = new Result("E100","User Id cannot be empty", "Check ID");
			return result;
		}
		Result resultMand = validationMandatory(user);
		if (resultMand != null)
			return resultMand;

		if (userDbData.isEmpty()) {
			if (userDbData1 == null) {
				if (userDbData2 == null) {
					userResponse = repository.save(user);
					Result result = new Result("I100","User Data Saved in the DataBase", userResponse);
					return result;
				}
				return new Result("E100","Phone Number is already registered", "");
			}
			return new Result("E100","Email Address is already registered", "");
		}
		return new Result("E100","This Employee Is Already Registered", "");

	}

	@Override
	public Result saveUser(@Valid User user) {

		if (user != null) {
			Result result1 = validation(user);
			return result1;
		}
		return new Result("E100","Please send user details", "");

	}
	
	@Override
	public List<Result> saveAllData(@Valid List<User> user) {
		
		List<Result> results=new ArrayList<>();
		for (User userData : user) {
				Result result1 = validation(userData);
				results.add(result1);
		}
		return results;
	}

	@Override
	public List<User> fetchAllData() {
		return repository.findAll();
	}

	@Override
	public Result fetchById(String userId) throws ResourceNotFoundException {
		Result result = new Result();
		Optional<User> user = repository.findById(userId);
		// .orElseThrow(()->new ResourceNotFoundException("User Not found for this is id
		// "+userId));
		if (!user.isEmpty()) {
			result.setCode("I100");
			result.setData(user.get());
			result.setMessage("Success");
		} else {
			result.setCode("E100");
			result.setMessage("User not exist");
		}
		return result;
	}

	@Override
	public Result fetchByEmail(String userEmailId) throws ResourceNotFoundException {
		Result result = new Result();
		User user = repository.findByUserEmailId(userEmailId);
		if (user == null) {
			throw new ResourceNotFoundException("User Not found for this is emailId " + userEmailId);
		}
		else {
			result.setCode("I100");
			result.setData(user);
			result.setMessage("Success");
		}
		return result;
	}

	@Override
	public Result fetchByPhone(String phoneNumber) throws ResourceNotFoundException {
		Result result = new Result();
		List<User> userDb = fetchAllData();
		String[] phone = phoneNumber.split("-", 2);
		for (User user : userDb) {
			if ((user.getPhoneNumber().split("-", 2)[1].equals(phone[1]))) {
				result.setCode("I100");
				result.setData(user);
				result.setMessage("Success");
			} else {
				result.setCode("E100");
				result.setMessage("User not exist");
			}
		}
		return result;
	}

	@Override
	public Result deleteById(String userId) {
		Result result = new Result();
		Optional<User> user = repository.findById(userId);
		if (!user.isEmpty()) {
			result.setMessage("Deleted Succesfully");
			repository.deleteById(userId);
		} else {
			result.setCode("E100");
			result.setMessage("data not exist");
		}
		return result;

	}

	@Override
	public Result updateById(String userId, User user) {
		User userdb = repository.findById(userId).get();

		if (userdb == null) {
			return new Result("E100","Data Not exist", "");

		}

		if (Objects.nonNull(user.getFirstName()) && !"".equalsIgnoreCase(user.getFirstName())) // if null and empty data
																								// then skip that data
		{
			userdb.setFirstName(user.getFirstName());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(user.getLastName()) && !"".equalsIgnoreCase(user.getLastName())) {
			userdb.setLastName(user.getLastName());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(user.getGender()) && !"".equalsIgnoreCase(user.getGender())) {
			userdb.setGender(user.getGender());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(user.getUserEmailId()) && !"".equalsIgnoreCase(user.getUserEmailId())) {
			userdb.setUserEmailId(user.getUserEmailId());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(user.getPhoneNumber())) {
			userdb.setPhoneNumber(user.getPhoneNumber());
		}
		if (Objects.nonNull(user.getDateOfBirth()) && !"".equalsIgnoreCase(user.getDateOfBirth())) {
			userdb.setDateOfBirth(user.getDateOfBirth());
		}
		if (Objects.nonNull(user.getPassword()) && !"".equalsIgnoreCase(user.getPassword())) {
			userdb.setPassword(user.getPassword());
		}
		if (Objects.nonNull(user.getCreateDate()) && !"".equalsIgnoreCase(user.getCreateDate())) {
			userdb.setCreateDate(user.getCreateDate());
		}
		if (Objects.nonNull(user.getUpdateDate()) && !"".equalsIgnoreCase(user.getUpdateDate())) {
			userdb.setUpdateDate(user.getUpdateDate());
		}

		Result resultMand = validationMandatory(user);
		if (resultMand != null)
			return resultMand;

		return new Result("I100","User details Updated", userdb);
	}

	

	public List<User> fetchByDate(String fromDate, String toDate) throws ResourceNotFoundException {

//		int from=Integer.parseInt(fromDate);
//		int to=Integer.parseInt(toDate);
//		List<User> userDb=repository.findAll();
//		List<User> user2=new ArrayList<>();
//		for (User userData : userDb) {
//			String[] str=userData.getCreateDate().split("/");
//			int val=Integer.parseInt(str[0]);
//			if((val>=from) && (val<=to))
//			{
//				user2.add(userData);
//			}
//		}
//		return  user2;
		if ((LocalDate.parse(fromDate)).isAfter(LocalDate.parse(toDate))) {
			throw new ResourceNotFoundException("Start Date Should be After End date");
		}
		List<User> userDb = repository.findAll();
		List<User> filteredUser = userDb.stream().filter(userDate -> {
			if ((LocalDate.parse(userDate.getCreateDate()).isEqual(LocalDate.parse(fromDate))
					|| LocalDate.parse(userDate.getCreateDate()).isAfter(LocalDate.parse(fromDate)))
					&& (LocalDate.parse(userDate.getCreateDate()).isEqual(LocalDate.parse(toDate))
							|| LocalDate.parse(userDate.getCreateDate()).isBefore(LocalDate.parse(toDate)))) {
				return true;
			}
			return false;
		}).collect(Collectors.toList());
		return filteredUser;

	}

}
