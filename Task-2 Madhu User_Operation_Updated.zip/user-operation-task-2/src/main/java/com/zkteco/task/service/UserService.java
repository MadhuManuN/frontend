package com.zkteco.task.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Result;
import com.zkteco.task.entity.User;
import com.zkteco.task.entity.UserDto;
import com.zkteco.task.exception.ResourceNotFoundException;

import jakarta.validation.Valid;


@Service
public interface UserService {
	
	
	public Result saveUser(@Valid User user);
	
	public List<Result> saveAllData(@Valid List<User> user);
	
	public List<User> fetchAllData();
	
	public Result fetchById(String userId) throws ResourceNotFoundException;
	
	public Result fetchByEmail(String userEmailId) throws ResourceNotFoundException;
	
	public Result fetchByPhone(String phoneNumber) throws ResourceNotFoundException;
	
	public Result deleteById(String userId);
	
	public Result updateById(String userId, User user);
	
	public List<User> fetchByDate(String fromDate, String toDate) throws ResourceNotFoundException;

}
