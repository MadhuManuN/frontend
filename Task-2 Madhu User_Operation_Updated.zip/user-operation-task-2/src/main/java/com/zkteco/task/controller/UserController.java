package com.zkteco.task.controller;


import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.task.entity.Result;
import com.zkteco.task.entity.User;
import com.zkteco.task.entity.UserDto;
import com.zkteco.task.exception.ResourceNotFoundException;
import com.zkteco.task.service.UserService;
import com.zkteco.task.service.UserServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	private UserService service;
	
	@Autowired
	private ModelMapper modelMapper;


		private final Logger logger=LoggerFactory.getLogger(UserController.class);
		
//////////////////////Saving data in DB(Save API)//////////

	@PostMapping("/user")
	public Result saveUser(@Valid @RequestBody UserDto userDto) {
		// convert DTO to entity
		User user = modelMapper.map(userDto, User.class);
		logger.info("Inside save User Method");
		return service.saveUser(user);
	}

	@PostMapping("/user/batch")
	public List<Result> saveMultipleData(@Valid @RequestBody List<User> user) {
		return service.saveAllData(user);
	}

//////////////Fetching data from DB/////////////////

	@GetMapping("/user/all")
	public List<User> fetchAllData() {
		logger.info("Inside Fetch User Method");
		return service.fetchAllData();
	}

/////////////////////////////Fetching Data by ID and email and phonenumber//////////////////

	@GetMapping("/user/{id}")
	public Result fetchById(@PathVariable(value = "id") String userId) throws ResourceNotFoundException {
		logger.info("Inside FetchBy ID User Method");
		return service.fetchById(userId);
	}

	@GetMapping("/user/userEmailId")
	public Result fetchByEmail(@RequestParam String userEmailId) throws ResourceNotFoundException {
		logger.info("Inside FetchBy EmailId User Method");
		return service.fetchByEmail(userEmailId);
	}
	
	@GetMapping("/user/phoneNumber")
	public Result fetchByPhone(@RequestParam String phoneNumber) throws ResourceNotFoundException {
		logger.info("Inside FetchBy phone number User Method");
		return service.fetchByPhone(phoneNumber);
	}
	
	@GetMapping("/user/{fromDate}/{toDate}")
	public List<User> fetchByDate(@PathVariable(value = "fromDate") String fromDate,@PathVariable(value = "toDate") String toDate) throws ResourceNotFoundException {
		logger.info("Inside FetchBy Date User Method");
		return service.fetchByDate(fromDate,toDate);
	}
	
/////////////////////////////Deleting Data by ID/////////////////

	@DeleteMapping("/user/{id}")
	public Result deleteById(@PathVariable("id") String userId) throws ResourceNotFoundException {
		logger.info("Inside Delete by ID Method");
		
		return service.deleteById(userId);
	}

////////////////////////////Updating Data by ID///////////////////

	@PutMapping("/user/{id}")
	public Result updateById(@PathVariable(value = "id") String userId, @RequestBody User user) {
		logger.info("Inside Update By ID User Method");
		return service.updateById(userId, user);
	}

}
