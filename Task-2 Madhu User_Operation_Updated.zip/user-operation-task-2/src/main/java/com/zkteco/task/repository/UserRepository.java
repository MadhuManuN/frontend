package com.zkteco.task.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.zkteco.task.entity.User;
import com.zkteco.task.entity.UserDto;

@Repository
public interface UserRepository extends JpaRepository<User, String> {
	
	public User findByUserEmailId(String userEmailId);

	public User findByphoneNumber(String phoneNumber);
	
	public List<User> findByCreateDate(String createDate);
	
}
