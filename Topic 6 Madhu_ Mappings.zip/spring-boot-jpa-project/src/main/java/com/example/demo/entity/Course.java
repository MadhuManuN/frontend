package com.example.demo.entity;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;

import javax.management.loading.PrivateClassLoader;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "Course")
public class Course {
	
	@Id
	@SequenceGenerator(
			name = "course_Sequence",
			sequenceName = "course_Sequence",
			allocationSize = 1
			)
	@GeneratedValue(
			strategy = GenerationType.SEQUENCE,
			generator = "course_Sequence"
			)
	private Long courseId;
	private String title;
	private Integer credit;
	
	@OneToOne(mappedBy = "course")
	private CourseMaterial courseMaterial;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(
			name = "teacher_id",
			referencedColumnName = "teacherId"
			)
	private Teacher teacher;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(
			name = "Student_Course_Map",
			joinColumns = @JoinColumn(
					name = "Course_Id",
					referencedColumnName = "courseId"
					),
			inverseJoinColumns = @JoinColumn(
					name = "Student_Id",
					referencedColumnName = "studentId"
					)
			)
	private List<Student> students;
	
	public void addStudents(Student student)
	{
		if(students==null) students=new ArrayList<>();
		students.add(student);
	}
}
