package com.example.demo.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "STUDENT_TABLE",
uniqueConstraints = @UniqueConstraint(columnNames = "Email_Id",name = "emailId_unique")
)
public class Student {

	@Id
	@SequenceGenerator(
			name = "Student_sequence",
			sequenceName = "Student_sequence",
			initialValue = 1,
			allocationSize = 50
			)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "Student_sequence")
	private Long studentId;
	
	@Column(name = "First_Name")
	private String firstName;
	@Column(name = "Last_Name")
	private String LastName;
	@Column(name = "Email_Id",nullable = false)
	private String emailId;
	
	@Embedded
	private Guardian guardian;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(
			name = "Student_Course_Map",
			joinColumns = @JoinColumn(
					name = "Student_Id",
					referencedColumnName = "studentId"
					),
			inverseJoinColumns = @JoinColumn(
					name = "Course_Id",
					referencedColumnName = "courseId"
					)
			)
	private List<Course> courses;
	
	public void addCourses(Course course)
	{
		if(courses==null) courses=new ArrayList<>();
		courses.add(course);
	}
}
