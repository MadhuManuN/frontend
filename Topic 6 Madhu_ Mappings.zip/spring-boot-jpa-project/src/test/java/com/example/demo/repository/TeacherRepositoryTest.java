package com.example.demo.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Course;
import com.example.demo.entity.Teacher;

@SpringBootTest
class TeacherRepositoryTest {

	@Autowired
	private TeacherRepository repository;
	
	@Test
	public void saveTeacher() {
		
		Course course1=Course.builder()
				.title("Java")
				.credit(15)
				.build();
		Course course2=Course.builder()
				.title("React JS")
				.credit(20)
				.build();
		
		Teacher teacher=Teacher.builder()
				.firstName("Manoj")
				.lastName("Kumar")
//				.course(List.of(course1,course2))
				.build();
		repository.save(teacher);
	}

}
