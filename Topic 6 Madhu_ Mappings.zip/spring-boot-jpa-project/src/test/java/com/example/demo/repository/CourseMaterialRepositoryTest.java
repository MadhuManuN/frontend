package com.example.demo.repository;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;

import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Course;
import com.example.demo.entity.CourseMaterial;

@SpringBootTest
class CourseMaterialRepositoryTest {

	@Autowired
	private CourseMaterialRepository repository;
	@Test
	public void saveCourseMaterial() {
		Course course=Course.builder()
				.title(".net")
				.credit(13)
				.build();
		CourseMaterial courseMaterial=CourseMaterial.builder()
				.url("www.javadoc.com")
				.course(course)
				.build();
		
		repository.save(courseMaterial);
	}

	
	public void printAllCourseMaterials()
	{
		List<CourseMaterial> materials=repository.findAll();
		System.out.println(materials);
		
		
	}
}
