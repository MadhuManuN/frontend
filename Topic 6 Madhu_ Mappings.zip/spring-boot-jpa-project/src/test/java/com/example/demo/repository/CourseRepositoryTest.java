package com.example.demo.repository;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Course;
import com.example.demo.entity.Student;
import com.example.demo.entity.Teacher;

@SpringBootTest
class CourseRepositoryTest {

	@Autowired
	private CourseRepository repository;
	

	void printAllCourseMaterials() {
		List<Course> courses=repository.findAll();
		
		System.out.println(courses);
		
	}
	

	public void saveCourseWithTeacher()
	{
		Teacher teacher=Teacher.builder()
				.firstName("Syed")
				.lastName("Imran")
				.build();
		Course course=Course.builder()
				.title("JAVA Script")
				.credit(20)
				.teacher(teacher)
				.build();
		repository.save(course);
	}

	public void findAllPagination()
	{
		Pageable firstPageWithThreeRecords=PageRequest.of(0, 3);
		Pageable firstPageWithTwoRecords=PageRequest.of(0, 2);
		
		List<Course> courses=repository.findAll(firstPageWithThreeRecords).getContent();
		int totalPages=repository.findAll(firstPageWithThreeRecords).getTotalPages();
		Long totalElements=repository.findAll(firstPageWithThreeRecords).getTotalElements();
		
		System.out.println(courses);
		System.out.println("Total pages:"+totalPages);
		System.out.println("Total elements:"+totalElements);
		
	}


	public void findAllSorting()
	{
		Pageable sortByTitle=PageRequest.of(0, 5, Sort.by("title"));
		
		Pageable sortByCreditDesc=PageRequest.of(0, 5, Sort.by("credit").descending());
		
		Pageable sortByTitleAndCreditDesc=PageRequest.of(0, 2,  Sort.by("title").descending().and(Sort.by("credit")));
		
		List<Course> courses=repository.findAll(sortByTitle).getContent();
		
		System.out.println(courses);
	}

	public void printFindByTitleContaining()
	{
		Pageable firstPageTenRecords=PageRequest.of(0, 10);
		
		List<Course> courses=repository.findByTitleContaining("JAVA Script", firstPageTenRecords).getContent();
		
		System.out.println("Courses by Title Sorting:"+courses);
	}
	
	@Test
	public void saveCourseWithStudnetAndTeacher()
	{
		Teacher teacher=Teacher.builder()
				.firstName("Syed")
				.lastName("Imran Khan")
				.build();
		
		Student student1=Student.builder()
				.firstName("Madhu")
				.LastName("Manu")
				.emailId("madhumanu1@gmail.com")
				.build();
		Student student2=Student.builder()
				.firstName("Jagnya")
				.LastName("Narayan")
				.emailId("jagnya123@gmail.com")
				.build();
		
		Course course=Course.builder()
				.title("React Js")
				.credit(30)
				.teacher(teacher)
				.build();
		
		course.addStudents(student1);
		course.addStudents(student2);
		
		repository.save(course);
	}
}
