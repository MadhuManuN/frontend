package com.zkteco.task.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "Designation")
public class Designation {
	@Id
	@Column(name = "Designation_Id")
	private String desigId;
	
	@Column(name = "Designation_Code")
	private String desigCode;
	
	@Column(name = "Designation_Name")
	private String desigName;
	
	@Column(name = "Created_Date")
	private String createDate;
	
	@Column(name = "Updated_Date")
	private String updateDate;

	@OneToMany(mappedBy = "designation", cascade = CascadeType.REMOVE)
	@JsonIgnore
	private List<Employee> employees;

}
