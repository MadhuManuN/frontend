package com.zkteco.task.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "Department")
public class Department {

	@Id
	@Column(name = "Department_Id")
	private String deptId;

	@Column(name = "Department_Code")
	private String deptCode;

	@Column(name = "Department_Name")
	private String deptName;

	@Column(name = "Created_Date")
	private String createDate;

	@Column(name = "Updated_Date")
	private String updateDate;

	@OneToMany(mappedBy = "department",cascade = CascadeType.REMOVE)
	@JsonIgnore
	private List<Employee> employees;

}
