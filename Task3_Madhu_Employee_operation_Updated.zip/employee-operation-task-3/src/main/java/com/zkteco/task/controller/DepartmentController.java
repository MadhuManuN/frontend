package com.zkteco.task.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.task.entity.Department;
import com.zkteco.task.entity.Employee;
import com.zkteco.task.entity.Result;
import com.zkteco.task.exception.ResourceNotFoundException;
import com.zkteco.task.service.DepartmentService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@RestController
public class DepartmentController {
	
	@Autowired
	private DepartmentService departmentService;
	
	private final Logger logger = LoggerFactory.getLogger(DepartmentController.class);
	
	@PostMapping("/department")
	public Result saveDepartment(@Valid @RequestBody Department department,HttpServletRequest request) {
		logger.info("Inside save Department Method");
		return departmentService.saveDepartment(department,request);
	}
	
	@PostMapping("/department/batch")
	public List<Result> saveMultipleData(@Valid @RequestBody List<Department> department,HttpServletRequest request) {
		return departmentService.saveAllData(department,request);
	}
	
	@GetMapping("/department/all")
	public List<Department> fetchAllData() {
		logger.info("Inside Fetch Employee Method");
		return departmentService.fetchAllData();
	}
	
	@GetMapping("/department/{id}")
	public Result fetchById(@PathVariable(value = "id") String deptId,HttpServletRequest request) throws ResourceNotFoundException {
		logger.info("Inside FetchBy ID Employee Method");
		return departmentService.fetchById(deptId,request);
	}
	
	@DeleteMapping("/department/{id}")
	public Result deleteById(@PathVariable("id") String deptId,HttpServletRequest request) throws ResourceNotFoundException {
		logger.info("Inside Delete by ID Method");

		return departmentService.deleteById(deptId,request);
	}
	
	@PutMapping("/department/{id}")
	public Result updateById(@PathVariable(value = "id") String deptId, @RequestBody Department department,HttpServletRequest request) {
		logger.info("Inside Update By ID Employee Method");
		return departmentService.updateById(deptId, department,request);
	}

}
