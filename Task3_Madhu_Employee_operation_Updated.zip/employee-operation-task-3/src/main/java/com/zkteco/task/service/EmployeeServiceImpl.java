package com.zkteco.task.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Result;
import com.zkteco.task.MyLocaleResolver;
import com.zkteco.task.entity.Department;
import com.zkteco.task.entity.Designation;
import com.zkteco.task.entity.Employee;
import com.zkteco.task.exception.ResourceNotFoundException;
import com.zkteco.task.repository.DepartmentRepository;
import com.zkteco.task.repository.DesignationRepository;
import com.zkteco.task.repository.EmployeeRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;


@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository repository;
	@Autowired
	private DepartmentRepository deptRepository;
	
	@Autowired
	private DesignationRepository desigRepository;
	
	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private MyLocaleResolver localeResolver;

	public Result validationMandatory(Employee employee,HttpServletRequest request) {
		String message1=messageSource.getMessage("name_len", null, localeResolver.resolveLocale(request));
		String message2=messageSource.getMessage("name_emp", null, localeResolver.resolveLocale(request));
		String message3=messageSource.getMessage("l_name_len", null, localeResolver.resolveLocale(request));
		String message4=messageSource.getMessage("gender_len", null, localeResolver.resolveLocale(request));
		String message5=messageSource.getMessage("email_err", null, localeResolver.resolveLocale(request));
		String message6=messageSource.getMessage("email_emp", null, localeResolver.resolveLocale(request));
		String message7=messageSource.getMessage("phone_inv", null, localeResolver.resolveLocale(request));
		String message8=messageSource.getMessage("phone_err", null, localeResolver.resolveLocale(request));
		String message9=messageSource.getMessage("phone_wrong", null, localeResolver.resolveLocale(request));
		String message10=messageSource.getMessage("phone_code", null, localeResolver.resolveLocale(request));
		String message11=messageSource.getMessage("phone_emp", null, localeResolver.resolveLocale(request));
		String message12=messageSource.getMessage("password_inv", null, localeResolver.resolveLocale(request));
		String message13=messageSource.getMessage("password_len", null, localeResolver.resolveLocale(request));
		String message14=messageSource.getMessage("password_dig", null, localeResolver.resolveLocale(request));
		String message15=messageSource.getMessage("password_upper", null, localeResolver.resolveLocale(request));
		String message16=messageSource.getMessage("password_emp", null, localeResolver.resolveLocale(request));
		
		String firstName = employee.getFirstName();
		String email = employee.getEmployeeEmailId();
		String phone = employee.getPhoneNumber();
		String password = employee.getPassword();
		if (!firstName.isEmpty()) {
			if (firstName.length() >= 10) {
				return new Result("E100",message1, "");
			}
		} else {
			return new Result("E100",message2, "");
		}
		if (employee.getLastName().length() >= 6) {
			return new Result("E100",message3, "");
		}
		if (employee.getGender().length() > 2) {
			return new Result("E100",message4, "");
		}
		if (!email.isEmpty()) {
			if (!email.contains(".") && !email.contains("@")) {
				Result result = new Result("E100",message5, "Invalid");
				return result;
			} else if (!email.contains("@")) {
				Result result = new Result("E100",message5, "");
				return result;
			} else if (!email.contains(".")) {
				Result result = new Result("E100",message5, "");
				return result;
			}
		} else {
			Result result = new Result("E100",message6, "");
			return result;
		}

		if (!phone.isEmpty()) {
			String[] arr = phone.split("-", 2);
			if (phone.length() > 14) {
				Result result = new Result("E100",message7, "");
				return result;
			} else if (!phone.contains("-") && !phone.contains("+")) {
				Result result = new Result("E100",message8, "");
				return result;
			} else if (!phone.contains("+")) {
				Result result = new Result("E100",message8, "");
				return result;
			} else if (!phone.contains("-")) {
				Result result = new Result("E100",message8, "");
				return result;
			}

			if (!(arr[1].length() == 10)) {
				Result result = new Result("E100",message9, "");
				return result;
			} else if (!arr[0].contains("+91") && !(arr[0].length() == 3)) {
				Result result = new Result("E100",message10, "");
				return result;
			}
		} else {
			Result result = new Result("E100",message11, "");
			return result;
		}

		if (!password.isEmpty()) {
			if (!(password.matches("(([a-zA-Z].*[0-9])|([0-9].*[a-zA-Z]))"))) {
				return new Result("E100",message12, "");
			}
			if (!(password.length() >= 8 && password.length() <= 20)) {
				return new Result("E100",message13, "");
			} else if (!(password.matches(".*[0-9]{2,}.*"))) {
				return new Result("E100",message14, "Invalid");
			} else if (!(password.matches(".*[A-Z]{1,}.*"))) {
				return new Result("E100",message15, "Invalid");
			}
		} else {
			return new Result("E100",message16, "");
		}
		return null;

	}

	public Result validation(Employee employee,HttpServletRequest request) {
		Optional<Employee> employeeDbData = repository.findById(employee.getEmployeeId());
		Employee employeeDbData1 = repository.findByEmployeeEmailId(employee.getEmployeeEmailId());
		Employee employeeDbData2 = repository.findByphoneNumber(employee.getPhoneNumber());
		Employee employeeResponse = new Employee();
		String message17=messageSource.getMessage("id_len", null, localeResolver.resolveLocale(request));
		String message18=messageSource.getMessage("id_emp", null, localeResolver.resolveLocale(request));
		String message19=messageSource.getMessage("success", null, localeResolver.resolveLocale(request));
		String message20=messageSource.getMessage("phone_reg", null, localeResolver.resolveLocale(request));
		String message21=messageSource.getMessage("email_reg", null, localeResolver.resolveLocale(request));
		String message22=messageSource.getMessage("data_reg", null, localeResolver.resolveLocale(request));
		

		if (employee.getEmployeeId().length() != 0) {
			if (employee.getEmployeeId().length() >= 4) {
				Result result = new Result("E100",message17, "");
				return result;
			}
		} else {
			Result result = new Result("E100",message18, "");
			return result;
		}
		Result resultMand = validationMandatory(employee,request);
		if (resultMand != null)
			return resultMand;

		if (employeeDbData.isEmpty()) {
			if (employeeDbData1 == null) {
				if (employeeDbData2 == null) {
					Department deptDb = deptRepository.findById(employee.getDepartment().getDeptId()).orElse(null);
					Designation desigDb=desigRepository.findById(employee.getDesignation().getDesigId()).orElse(null);
			        if (deptDb == null) {
			            deptDb = new Department();
			        }
			        if(desigDb==null)
			        {
			        	desigDb=new Designation();
			        }
			        employee.setDesignation(desigDb);
			        employee.setDepartment(deptDb);
					employeeResponse = repository.save(employee);
					Result result = new Result("I100",message19, employeeResponse);
					return result;
				}
				return new Result("E100",message20, "");
			}
			return new Result("E100",message21, "");
		}
		return new Result("E100",message22, "");

	}

	@Override
	public Result saveEmployee(@Valid Employee employee,HttpServletRequest request) {
		String message23=messageSource.getMessage("request", null, localeResolver.resolveLocale(request));
		

		if (employee != null) {
			Result result1 = validation(employee,request);
			return result1;
		}
		return new Result("E100",message23, "");

	}
	
	@Override
	public List<Result> saveAllData(@Valid List<Employee> employee,HttpServletRequest request) {
		
		List<Result> results=new ArrayList<>();
		for (Employee employeeData : employee) {
				Result result1 = validation(employeeData,request);
				results.add(result1);
		}
		return results;
	}

	@Override
	public List<Employee> fetchAllData() {
		return repository.findAll();
	}

	@Override
	public Result fetchById(String employeeId,HttpServletRequest request) throws ResourceNotFoundException {
		String message24=messageSource.getMessage("no_data", null, localeResolver.resolveLocale(request));
		Result result = new Result();
		Optional<Employee> employee = repository.findById(employeeId);
		// .orElseThrow(()->new ResourceNotFoundException("User Not found for this is id
		// "+userId));
		if (!employee.isEmpty()) {
			result.setCode("I100");
			result.setData(employee.get());
			result.setMessage("Success");
		} else {
			result.setCode("E100");
			result.setMessage(message24);
		}
		return result;
	}

	@Override
	public Result fetchByEmail(String employeeEmailId,HttpServletRequest request) throws ResourceNotFoundException {
		String message25=messageSource.getMessage("no_email_data", null, localeResolver.resolveLocale(request));
		Result result = new Result();
		Employee employee = repository.findByEmployeeEmailId(employeeEmailId);
		if (employee == null) {
			throw new ResourceNotFoundException(message25 + employeeEmailId);
		}
		else {
			result.setCode("I100");
			result.setData(employee);
			result.setMessage("Success");
		}
		return result;
	}

	@Override
	public Result fetchByPhone(String phoneNumber,HttpServletRequest request) throws ResourceNotFoundException {
		String message24=messageSource.getMessage("no_data", null, localeResolver.resolveLocale(request));
		Result result = new Result();
		List<Employee> employeeDb = fetchAllData();
		String[] phone = phoneNumber.split("-", 2);
		for (Employee employee : employeeDb) {
			if ((employee.getPhoneNumber().split("-", 2)[1].equals(phone[1]))) {
				result.setCode("I100");
				result.setData(employee);
				result.setMessage("Success");
			} else {
				result.setCode("E100");
				result.setMessage(message24);
			}
		}
		return result;
	}

	@Override
	public Result deleteById(String employeeId,HttpServletRequest request) {
		String messageDel=messageSource.getMessage("delMessage", null, localeResolver.resolveLocale(request));
		String message24=messageSource.getMessage("no_data", null, localeResolver.resolveLocale(request));
		Result result = new Result();
		Optional<Employee> employee = repository.findById(employeeId);
		if (!employee.isEmpty()) {
			result.setMessage(messageDel);
			repository.deleteById(employeeId);
		} else {
			result.setCode("E100");
			result.setMessage(message24);
		}
		return result;

	}

	@Override
	public Result updateById(String employeeId, Employee employee,HttpServletRequest request) {
		String message24=messageSource.getMessage("no_data", null, localeResolver.resolveLocale(request));
		Result result;
		Employee employeedb = repository.findById(employeeId).get();

		if (employeedb == null) {
			return new Result("E100",message24, "");

		}

		if (Objects.nonNull(employee.getFirstName()) && !"".equalsIgnoreCase(employee.getFirstName())) // if null and empty data
																								// then skip that data
		{
			employeedb.setFirstName(employee.getFirstName());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(employee.getLastName()) && !"".equalsIgnoreCase(employee.getLastName())) {
			employeedb.setLastName(employee.getLastName());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(employee.getGender()) && !"".equalsIgnoreCase(employee.getGender())) {
			employeedb.setGender(employee.getGender());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(employee.getEmployeeEmailId()) && !"".equalsIgnoreCase(employee.getEmployeeEmailId())) {
			employeedb.setEmployeeEmailId(employee.getEmployeeEmailId());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(employee.getPhoneNumber())) {
			employeedb.setPhoneNumber(employee.getPhoneNumber());
		}
		if (Objects.nonNull(employee.getDateOfBirth()) && !"".equalsIgnoreCase(employee.getDateOfBirth())) {
			employeedb.setDateOfBirth(employee.getDateOfBirth());
		}
		if (Objects.nonNull(employee.getPassword()) && !"".equalsIgnoreCase(employee.getPassword())) {
			employeedb.setPassword(employee.getPassword());
		}
		if (Objects.nonNull(employee.getCreateDate()) && !"".equalsIgnoreCase(employee.getCreateDate())) {
			employeedb.setCreateDate(employee.getCreateDate());
		}
		if (Objects.nonNull(employee.getUpdateDate()) && !"".equalsIgnoreCase(employee.getUpdateDate())) {
			employeedb.setUpdateDate(employee.getUpdateDate());
		}

		Result resultMand = validationMandatory(employee,request);
		if (resultMand != null) {
			return resultMand;
		}
		else {
			result=new Result("I100","Employee details Updated", employeedb);
			repository.save(employeedb);
		}
		return result;
	}

	

	public List<Employee> fetchByDate(String fromDate, String toDate,HttpServletRequest request) throws ResourceNotFoundException {
		String message26=messageSource.getMessage("date_rev", null, localeResolver.resolveLocale(request));

//		int from=Integer.parseInt(fromDate);
//		int to=Integer.parseInt(toDate);
//		List<User> userDb=repository.findAll();
//		List<User> user2=new ArrayList<>();
//		for (User userData : userDb) {
//			String[] str=userData.getCreateDate().split("/");
//			int val=Integer.parseInt(str[0]);
//			if((val>=from) && (val<=to))
//			{
//				user2.add(userData);
//			}
//		}
//		return  user2;
		if ((LocalDate.parse(fromDate)).isAfter(LocalDate.parse(toDate))) {
			throw new ResourceNotFoundException(message26);
		}
		List<Employee> employeeDb = repository.findAll();
		List<Employee> filteredEmployee = employeeDb.stream().filter(employeeDate -> {
			if ((LocalDate.parse(employeeDate.getCreateDate()).isEqual(LocalDate.parse(fromDate))
					|| LocalDate.parse(employeeDate.getCreateDate()).isAfter(LocalDate.parse(fromDate)))
					&& (LocalDate.parse(employeeDate.getCreateDate()).isEqual(LocalDate.parse(toDate))
							|| LocalDate.parse(employeeDate.getCreateDate()).isBefore(LocalDate.parse(toDate)))) {
				return true;
			}
			return false;
		}).collect(Collectors.toList());
		return filteredEmployee;

	}

}
