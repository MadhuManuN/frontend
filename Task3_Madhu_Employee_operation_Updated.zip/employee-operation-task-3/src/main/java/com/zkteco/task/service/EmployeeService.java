package com.zkteco.task.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Result;
import com.zkteco.task.entity.Employee;
import com.zkteco.task.exception.ResourceNotFoundException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;


@Service
public interface EmployeeService {
	
	
	public Result saveEmployee(@Valid Employee employee,HttpServletRequest request);
	
	public List<Result> saveAllData(@Valid List<Employee> employee,HttpServletRequest request);
	
	public List<Employee> fetchAllData();
	
	public Result fetchById(String employeeId,HttpServletRequest request) throws ResourceNotFoundException;
	
	public Result fetchByEmail(String employeeEmailId,HttpServletRequest request) throws ResourceNotFoundException;
	
	public Result fetchByPhone(String phoneNumber,HttpServletRequest request) throws ResourceNotFoundException;
	
	public Result deleteById(String employeeId,HttpServletRequest request);
	
	public Result updateById(String employeeId, Employee employee,HttpServletRequest request);
	
	public List<Employee> fetchByDate(String fromDate, String toDate,HttpServletRequest request) throws ResourceNotFoundException;

}
