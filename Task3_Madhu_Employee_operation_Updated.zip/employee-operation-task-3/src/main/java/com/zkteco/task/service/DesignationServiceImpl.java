package com.zkteco.task.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.zkteco.task.MyLocaleResolver;
import com.zkteco.task.entity.Designation;
import com.zkteco.task.entity.Result;
import com.zkteco.task.repository.DesignationRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@Service
public class DesignationServiceImpl implements DesignationService {

	@Autowired
	private DesignationRepository repository;
	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private MyLocaleResolver localeResolver;


	public Result validationMandatory(Designation designation,HttpServletRequest request) {
		String message1=messageSource.getMessage("name_len", null, localeResolver.resolveLocale(request));
		String message2=messageSource.getMessage("name_emp", null, localeResolver.resolveLocale(request));
		String message27=messageSource.getMessage("code_len", null, localeResolver.resolveLocale(request));
		String message28=messageSource.getMessage("code_emp", null, localeResolver.resolveLocale(request));
		String name = designation.getDesigName();
		String code = designation.getDesigCode();

		if (!name.isEmpty()) {
			if (name.length() >= 50) {
				return new Result("E100", message1, "");
			}
		} else {
			return new Result("E100", message2, "");
		}
		if (!code.isEmpty()) {
			if (code.length() >= 30) {
				return new Result("E100", message27, "");
			}
		} else {
			return new Result("E100", message28, "");
		}
		return null;

	}

	public Result validation(Designation designation,HttpServletRequest request) {
		Optional<Designation> designationDbData = repository.findById(designation.getDesigId());
		Designation designationDbData1 = repository.findByDesigName(designation.getDesigName());
		Designation designationDbData2 = repository.findByDesigCode(designation.getDesigCode());
		Designation designationResponse = new Designation();
		String message17=messageSource.getMessage("id_len", null, localeResolver.resolveLocale(request));
		String message18=messageSource.getMessage("id_emp", null, localeResolver.resolveLocale(request));
		String message19=messageSource.getMessage("success", null, localeResolver.resolveLocale(request));
		String message22=messageSource.getMessage("data_reg", null, localeResolver.resolveLocale(request));
		String message29=messageSource.getMessage("code_reg", null, localeResolver.resolveLocale(request));
		String message30=messageSource.getMessage("name_reg", null, localeResolver.resolveLocale(request));

		if (designation.getDesigId().length() != 0) {
			if (designation.getDesigId().length() >= 4) {
				Result result = new Result("E100", message17, "Check ID Length");
				return result;
			}
		} else {
			Result result = new Result("E100", message18, "Check ID");
			return result;
		}
		Result resultMand = validationMandatory(designation,request);
		if (resultMand != null)
			return resultMand;

		if (designationDbData.isEmpty()) {
			if (designationDbData1 == null) {
				if (designationDbData2 == null) {
					designationResponse = repository.save(designation);
					Result result = new Result("I100", message19, designationResponse);
					return result;
				}
				return new Result("E100", message29, "");
			}
			return new Result("E100", message30, "");
		}
		return new Result("E100", message22, "");

	}
	@Override
	public Result saveDepartment(@Valid Designation designation,HttpServletRequest request) {
		String message23=messageSource.getMessage("request", null, localeResolver.resolveLocale(request));
		if (designation != null) {
			Result result1 = validation(designation,request);
			return result1;
		}
		return new Result("E100", message23, "");
	}

	@Override
	public List<Result> saveAllData(@Valid List<Designation> designation,HttpServletRequest request) {
		List<Result> results = new ArrayList<>();
		for (Designation designationData : designation) {
			Result result1 = validation(designationData,request);
			results.add(result1);
		}
		return results;
	}

	@Override
	public List<Designation> fetchAllData() {
		return repository.findAll();
	}

	@Override
	public Result fetchById(String desigId,HttpServletRequest request) {
		String message24=messageSource.getMessage("no_data", null, localeResolver.resolveLocale(request));
		Result result = new Result();
		Optional<Designation> designation = repository.findById(desigId);
		// .orElseThrow(()->new ResourceNotFoundException("User Not found for this is id
		// "+userId));
		if (!designation.isEmpty()) {
			result.setCode("I100");
			result.setData(designation.get());
			result.setMessage("Success");
		} else {
			result.setCode("E100");
			result.setMessage(message24);
		}
		return result;
	}

	@Override
	public Result deleteById(String desigId,HttpServletRequest request) {
		String message24=messageSource.getMessage("no_data", null, localeResolver.resolveLocale(request));
		String messageDel=messageSource.getMessage("delMessage", null, localeResolver.resolveLocale(request));
		Result result = new Result();
		Optional<Designation> designation = repository.findById(desigId);
		if (!designation.isEmpty()) {
			result.setCode("");
			result.setData("");
			result.setMessage(messageDel);
			repository.deleteById(desigId);
		} else {
			result.setCode("E100");
			result.setMessage(message24);
		}
		return result;
	}

	@Override
	public Result updateById(String desigId, Designation designation,HttpServletRequest request) {
		
		Result result;
		Designation designationDbData2 = repository.findByDesigName(designation.getDesigName());
		Designation designationDbData3 = repository.findByDesigCode(designation.getDesigCode());
		Designation designationdb = repository.findById(desigId).get();
		String message17=messageSource.getMessage("id_len", null, localeResolver.resolveLocale(request));
		String message18=messageSource.getMessage("id_emp", null, localeResolver.resolveLocale(request));
		String message24=messageSource.getMessage("no_data", null, localeResolver.resolveLocale(request));
		String message31=messageSource.getMessage("d_id_match", null, localeResolver.resolveLocale(request));
		String message29=messageSource.getMessage("code_reg", null, localeResolver.resolveLocale(request));
		String message30=messageSource.getMessage("name_reg", null, localeResolver.resolveLocale(request));
		String message32=messageSource.getMessage("d_data_update", null, localeResolver.resolveLocale(request));

		if (designationdb == null) {
			return new Result("E100", message24, "");
		}
		if (!(designation.getDesigId().equals(desigId))) {
			return new Result("E100", message31, "");
		}

		if (Objects.nonNull(designation.getDesigName()) && !"".equalsIgnoreCase(designation.getDesigName())) // if null and empty data then skip data
		{
			designationdb.setDesigName(designation.getDesigName());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(designation.getDesigCode()) && !"".equalsIgnoreCase(designation.getDesigCode())) {
			designationdb.setDesigCode(designation.getDesigCode());// if non null and not blank then we are setting the data
		}

		if (designation.getDesigId().length() != 0) {
			if (designation.getDesigId().length() >= 4) {
				Result result1 = new Result("E100",message17, "Check ID Length");
				return result1;
			}
		} else {
			Result result1 = new Result("E100", message18, "Check ID");
			return result1;
		}

		Result resultMand = validationMandatory(designation,request);
		if (resultMand != null) {
			return resultMand;
		}
		if (designationDbData2 == null) {
			if (designationDbData3 == null) {
				result = new Result("I100", message32, designationdb);
				repository.save(designationdb);
				return result;
			}
			return new Result("E100", message29, "");
		}
		return new Result("E100", message30, "");
	}

}
