package com.zkteco.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Employee")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long empId;
	
	@Column(name = "EMP_NAME")
	@NotBlank(message = "Please Add the employee name")
	@Size(min = 3,message = "Please enter minimum 3 characters")
	private String empName;
	@Column(name = "EMP_DESIGNATION")
	@NotBlank(message = "Please Add the employee name")
	@Size(min = 3,message = "Please enter minimum 3 characters")
	private String empDesignation;
	@Column(name = "EMP_COMPANY")
	private String empCompany;
	@Column(name = "EMP_LOCATION")
	private String empLocation;
	
	
	
}
