let fetchBtn = document.getElementById("fetchbtn");
fetchBtn.addEventListener('click', buttonClickHandler);
console.log("hello")
function buttonClickHandler() {
    console.log("You Have clicked the FetchButton");

    //instatntiate xhr object
    const xhr = new XMLHttpRequest();

    //open the text
    xhr.open('GET', 'https://jsonplaceholder.typicode.com/users',true);

    xhr.onload = function () {
        if (this.status == 200 && this.readyState == 4){
        let obj = JSON.parse(this.responseText);
        let tbody = document.getElementById("tbody");
        // for (let { id, name, username,email,phone,website } of obj) {
            for(let i=0;i<obj.length;i++){
            tbody.innerHTML +=
            `<tr>
            <td>${obj[i].id}</td>
            <td>${obj[i].name}</td>
            <td>${obj[i].username}</td>
            <td>${obj[i].email}</td>
            <td>${obj[i].address?.street}</td>
            <td>${obj[i].address?.suite}</td>
            <td>${obj[i].address?.city}</td>
            <td>${obj[i].address?.zipcode}</td>
            <td>${obj[i].address?.geo?.lat}</td>
            <td>${obj[i].address?.geo?.lng}</td>
            <td>${obj[i].phone}</td>
            <td>${obj[i].website}</td>
            <td>${obj[i]?.company?.name}</td>
            <td>${obj[i].company?.catchPhrase}</td>
            <td>${obj[i].company?.bs}</td>
        </tr>`
        }
    }
        else console.error("error has occured");
    }

    xhr.send();
    console.log("we are done!")
}