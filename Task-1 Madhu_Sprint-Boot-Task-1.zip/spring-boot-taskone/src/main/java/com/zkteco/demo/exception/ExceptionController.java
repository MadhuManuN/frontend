package com.zkteco.demo.exception;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;


@ControllerAdvice
@RestController
public class ExceptionController {

	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<?> handleException(Exception e) {
	    UserResponse response = null;

	    if(e instanceof DataIntegrityViolationException){
	        DataIntegrityViolationException ex = (DataIntegrityViolationException) e;
	        response = new UserResponse( "This is already Registered!");
	        
	    }
	    return new ResponseEntity<UserResponse>(response, HttpStatus.CONFLICT);
}
}
