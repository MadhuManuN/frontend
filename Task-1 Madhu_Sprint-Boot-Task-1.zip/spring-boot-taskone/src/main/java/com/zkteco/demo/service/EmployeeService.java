package com.zkteco.demo.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.zkteco.demo.entity.EmployeeData;
import com.zkteco.demo.repository.EmployeeRepository;

import jakarta.validation.Valid;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;

	public EmployeeData saveEmployee(@Valid EmployeeData employee) {
	
		return employeeRepository.save(employee);
	}

	public List<EmployeeData> fetchAllData() {
		return employeeRepository.findAll();
	}

	public EmployeeData fetchById(String empId) {
		return  employeeRepository.findById(empId).get(); 
		 
	}

	public void deleteById(String empId) {
		employeeRepository.deleteById(empId);
		
	}

	public EmployeeData updateById(String empId, EmployeeData employeeEntity) {
		EmployeeData empdb=employeeRepository.findById(empId).get();
		
		if(Objects.nonNull(employeeEntity.getFirstName()) && !"".equalsIgnoreCase(employeeEntity.getFirstName())) //if null and empty data then skip that data
		{
			empdb.setFirstName(employeeEntity.getFirstName());//if non null and not blank then we are setting the data
		}
		if(Objects.nonNull(employeeEntity.getLastName()) && !"".equalsIgnoreCase(employeeEntity.getLastName())) //if null and empty data then skip that data
		{
			empdb.setLastName(employeeEntity.getLastName());//if non null and not blank then we are setting the data
		}
		if(Objects.nonNull(employeeEntity.getGender()) && !"".equalsIgnoreCase(employeeEntity.getGender())) //if null and empty data then skip that data
		{
			empdb.setGender(employeeEntity.getGender());//if non null and not blank then we are setting the data
		}
		if(Objects.nonNull(employeeEntity.getEmpEmailId()) && !"".equalsIgnoreCase(employeeEntity.getEmpEmailId())) //if null and empty data then skip that data
		{
			empdb.setEmpEmailId(employeeEntity.getEmpEmailId());//if non null and not blank then we are setting the data
		}
		if(Objects.nonNull(employeeEntity.getPhoneNumber()))
		{
			empdb.setPhoneNumber(employeeEntity.getPhoneNumber());
		}
		if(Objects.nonNull(employeeEntity.getDateOfBirth()) && !"".equalsIgnoreCase(employeeEntity.getDateOfBirth()))
		{
			empdb.setDateOfBirth(employeeEntity.getDateOfBirth());
		}
		if(Objects.nonNull(employeeEntity.getProfilePhoto()) )
		{
			empdb.setProfilePhoto(employeeEntity.getProfilePhoto());
		}
		return employeeRepository.save(empdb);
	}


}
