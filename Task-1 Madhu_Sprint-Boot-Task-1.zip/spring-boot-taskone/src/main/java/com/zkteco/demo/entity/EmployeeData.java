package com.zkteco.demo.entity;


import org.checkerframework.common.aliasing.qual.Unique;
import org.hibernate.validator.constraints.Length;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "Employee_Data",uniqueConstraints = @UniqueConstraint(columnNames = {"Email_Id","Phone_Number","Emp_Id"},name = "email_phone"))
public class EmployeeData {
	
	@Id
	@Column(name = "Emp_Id")
	@NotEmpty(message = "Please enter the Id")
	@Size(max = 3,message = "Maximum length is 3")
	private String empId;
	
	@Column(name = "First_Name")
	@NotEmpty(message = "Please Add the employee name")
	@Size(max = 50,message = "Minimum Characters allowed is 50")
	private String firstName;
	
	@Column(name = "Last_Name")
	@Size(max = 50,message = "Minimum Characters allowed is 50")
	private String lastName;
	
	@Column(name = "Gender")
	@Size(max = 1,message = "There should be only one character")
	private String gender;
	
	@Column(name = "Email_Id",nullable = false,unique = true)
	@NotEmpty(message = "Please Add the Email Id")
	@Email
	@Pattern(regexp = "[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}")
	private String empEmailId;
	
	@Column(name = "Phone_Number",nullable = false,unique = true)
	@NotEmpty(message = "Please Add the Phone Number")
	@Pattern(regexp = "^(\\+91[\\-\\s])\\d{10}$",message = "enter valid phonenumber")
	private String phoneNumber;
	
	@Column(name = "D_O_B")
	private String dateOfBirth;
	
	@Column(name = "Profile_Photo")
	private Boolean profilePhoto;

}
