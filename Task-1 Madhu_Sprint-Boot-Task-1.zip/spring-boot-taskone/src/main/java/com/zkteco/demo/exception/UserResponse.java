package com.zkteco.demo.exception;

public class UserResponse {
	    private String errorMsg;

	public UserResponse() {

	}

	    public UserResponse(String msg) {
	        this.errorMsg = msg;
	    }


	    public String getErrorMsg  () {
	        return errorMsg ;
	    }

	    public void setErrorMsg  (String errorMsg ) {
	        this.errorMsg = errorMsg ;
	    }
}
