package com.zkteco.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.zkteco.demo.entity.EmployeeData;


@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeData, String> {

}
