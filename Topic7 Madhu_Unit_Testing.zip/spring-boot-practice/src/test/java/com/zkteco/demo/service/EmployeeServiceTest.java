package com.zkteco.demo.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.zkteco.demo.model.EmployeeEntity;
import com.zkteco.demo.repo.EmployeeRepository;

@SpringBootTest
class EmployeeServiceTest {
	
	@Autowired
	private EmployeeService employeeService;
	
	@MockBean
	private EmployeeRepository employeeRepository;

	@BeforeEach
	void setUp() throws Exception {
		
		EmployeeEntity employeeEntity=
				EmployeeEntity.builder()
				.empName("madhu")
				.empCompany("ZKTECO")
				.empId(5l)
				.empDesignation("developer")
				.empLocation("Bengaluru")
				.build();
		
		Mockito.when(employeeRepository.findByEmpName("madhu")).thenReturn(employeeEntity);
	}

	@Test
	@DisplayName("GetDataBasedOn_ValidName")//more readable when multiple test cases added
	void whenvalidEmployeeName_thenEmplShldBeFound() {
		String empName="madhu";
		EmployeeEntity entity=employeeService.fetchDataByName(empName);
		
		assertEquals(empName, entity.getEmpName());
		
	}

}
