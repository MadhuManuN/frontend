package com.zkteco.demo.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.zkteco.demo.model.EmployeeEntity;
import com.zkteco.demo.service.EmployeeService;

@WebMvcTest(EmployeeController.class)
class EmployeeControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean//use MockMvc bean instance to invoke the APIs and verify the results.
	private EmployeeService employeeService;
	
	private List<EmployeeEntity> employeeEntities=new ArrayList<>();
	
	private EmployeeEntity employeeEntity;

	@BeforeEach
	void setUp() throws Exception {
		employeeEntity=EmployeeEntity.builder()
				.empId(1l)
				.empName("madhu")
				.empCompany("zkteco")
				.empDesignation("dev")
				.empLocation("bengaluru")
				.build();
		employeeEntities.add(employeeEntity);
	}
	
	@Test
	public void saveEmployee() throws Exception {
		EmployeeEntity inputEmployeeEntity=EmployeeEntity.builder()
				.empName("madhu")
				.empCompany("zkteco")
				.empDesignation("dev")
				.empLocation("bengaluru")
				.build();
		Mockito.when(employeeService.saveEmployee(inputEmployeeEntity)).thenReturn(employeeEntity);
		mockMvc.perform(MockMvcRequestBuilders.post("/employees")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\r\n"
						+ "    \"empName\":\"madhu\",\r\n"
						+ "    \"empDesignation\":\"dev\",\r\n"
						+ "    \"empCompany\":\"zkteco\",\r\n"
						+ "    \"empLocation\":\"bengaluru\"\r\n"
						+ "}"))
		.andExpect(MockMvcResultMatchers.status().isOk());
	}
	
	@Test
	public void fetchEmployeeById() throws Exception {
		Mockito.when(employeeService.fetchById(1l)).thenReturn(employeeEntity);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/employee/1")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(jsonPath("$.empName").value(employeeEntity.getEmpName()));
	}
	
	@Test
	public void fetchEmployees() throws Exception {
		Mockito.when(employeeService.fetchAllData()).thenReturn(employeeEntities);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/employees")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(jsonPath("$[0].empName").value(employeeEntities.get(0).getEmpName()));
	}
	
	@Test
	public void fetchEmployeeByName() throws Exception {
		Mockito.when(employeeService.fetchDataByName("madhu")).thenReturn(employeeEntity);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/employee/data/madhu")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(jsonPath("$.empDesignation").value(employeeEntity.getEmpDesignation()))
				.andExpect(jsonPath("$.empCompany").value(employeeEntity.getEmpCompany()));
	}
	
//	@Test
//	public void updateEmployeeById() throws Exception {
//		EmployeeEntity inputEmployeeEntity=EmployeeEntity.builder()
//				.empName("manu")
//				.empCompany("zkteco")
//				.empDesignation("dev")
//				.empLocation("bengaluru")
//				.build();
//		Mockito.when(employeeService.updateById(1l, inputEmployeeEntity)).thenReturn(employeeEntity);
//		
//		mockMvc.perform(MockMvcRequestBuilders.put("/employee/1l")
//				.contentType(MediaType.APPLICATION_JSON)
//				.content("{\r\n"
//						+ "    \"empName\":\"manu\",\r\n"
//						+ "    \"empDesignation\":\"dev\",\r\n"
//						+ "    \"empCompany\":\"zkteco\",\r\n"
//						+ "    \"empLocation\":\"bengaluru\"\r\n"
//						+ "}"))
//				.andExpect(MockMvcResultMatchers.status().isOk());
//				
//	}
	

//	@Test
//	void getEmployeeList() throws Exception {
//		List<EmployeeEntity> employees=new ArrayList<>();
//		EmployeeEntity employeeEntity=new EmployeeEntity();
//		employeeEntity.setEmpId(1l);
//		employeeEntity.setEmpName("madhu");
//		employeeEntity.setEmpCompany("deloitte");
//		employeeEntity.setEmpDesignation("dev");
//		employeeEntity.setEmpLocation("delhi");
//		employees.add(employeeEntity);
//		Mockito.when(employeeService.fetchAllData()).thenReturn(employees);
//		mockMvc.perform(get("/get/all")).andExpect(status().isOk()).andExpect(jsonPath("$",Matchers.hasSize(1)))
//		.andExpect(jsonPath("$[0].name",Matchers.equalTo("madhu")));
//	}

}
