package com.zkteco.demo.repo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.zkteco.demo.model.EmployeeEntity;

@RunWith(SpringRunner.class)
@ExtendWith(MockitoExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
class EmployeeRepositoryTest {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private TestEntityManager entityManager;

	@BeforeEach
	void setUp() throws Exception {
		
		EmployeeEntity employeeEntity=EmployeeEntity.builder()
				.empName("manu")
				.empCompany("deligent")
				.empDesignation("developer")
				.empId(10l)
				.empLocation("mysore")
				.build();
		
		entityManager.persist(employeeEntity);
	}

	@Test
	public void whenFindById_thenReturnEmployee() {
		
		EmployeeEntity employeeEntity1=employeeRepository.findById(10l).get();
	
		assertEquals("zkteco",employeeEntity1.getEmpCompany() );;
	}

}
