package com.zkteco.demo.repo;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.zkteco.demo.SpringBootPracticeApplication;
import com.zkteco.demo.model.EmployeeEntity;

import jakarta.transaction.Transactional;

@ExtendWith(SpringExtension.class)
@Transactional
@SpringBootTest(classes = SpringBootPracticeApplication.class)
class EmployeeRepositoryTest2 {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	 private EmployeeEntity getEmployee() {
		 EmployeeEntity employee = new EmployeeEntity();
	      employee.setEmpId(1l);
	      employee.setEmpName("madhu");
	      employee.setEmpCompany("deligate");
	      employee.setEmpDesignation("developer");
	      employee.setEmpLocation("mysuru");
	      return employee;
	   }
	 @Test
	   public void testFindById() {
		 EmployeeEntity employee = getEmployee();	     
	      employeeRepository.save(employee);
	      EmployeeEntity result = employeeRepository.findById(employee.getEmpId()).get();
	      assertEquals(employee.getEmpId(), result.getEmpId());	     
	   }
	 
	 @Test
	   public void testFindAll() {
		 EmployeeEntity employee = getEmployee();
	      employeeRepository.save(employee);
	      List<EmployeeEntity> result = new ArrayList<>();
	      employeeRepository.findAll().forEach(e -> result.add(e));
	      assertEquals(result.size(), 3);	     
	   }
	 
	 @Test
	   public void testSave() {
		 EmployeeEntity employee = getEmployee();
	      employeeRepository.save(employee);
	      EmployeeEntity found = employeeRepository.findById(employee.getEmpId()).get();
	      assertEquals(employee.getEmpId(), found.getEmpId());	     
	   }
	 
	 @Test
	   public void testDeleteById() {
		 EmployeeEntity employee = getEmployee();
	      employeeRepository.save(employee);
	      employeeRepository.deleteById(employee.getEmpId());
	      employeeRepository.deleteById(3l);
	      employeeRepository.deleteById(4l);
	      List<EmployeeEntity> result = new ArrayList<>();
	      employeeRepository.findAll().forEach(e -> result.add(e));
	      assertEquals(result.size(), 0);
	   }


}
