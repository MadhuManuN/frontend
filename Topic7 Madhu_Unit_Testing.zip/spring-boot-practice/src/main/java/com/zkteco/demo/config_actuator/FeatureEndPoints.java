package com.zkteco.demo.config_actuator;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Component
@Endpoint(id = "features")
public class FeatureEndPoints {
	
	private final Map<String, Feature> featuresMap=new ConcurrentHashMap<>();

	
	public FeatureEndPoints() {
		featuresMap.put("employee", new Feature(true));
		featuresMap.put("user", new Feature(false));
		featuresMap.put("Authentication", new Feature(false));
	}

	@ReadOperation
	public Map<String, Feature> features() ///endpoints ....so we create the methods...we send the list of features ....get operation so Readoperation
	{
		return featuresMap;
	}
	
	@ReadOperation
	public Feature features(@Selector String featureName)  /// endpoint for the particular feature ...among features..readoperation....this is selector
	{
		return featuresMap.get(featureName);
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	private static class Feature
	{
		private boolean isEnabled;
	}
}
