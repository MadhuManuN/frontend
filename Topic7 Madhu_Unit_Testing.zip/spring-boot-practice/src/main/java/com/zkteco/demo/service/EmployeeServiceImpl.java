package com.zkteco.demo.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zkteco.demo.exception.EmployeeNotFoundException;
import com.zkteco.demo.model.EmployeeEntity;
import com.zkteco.demo.repo.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	public EmployeeRepository employeeRepository;
	
	//////////////////////Saving data in DB(Save API)//////////
	
	@Override
	public EmployeeEntity saveEmployee(EmployeeEntity employeeEntity) {
		
		return employeeRepository.save(employeeEntity);
	}

	//////////////Fetching data from DB/////////////////
	
	@Override
	public List<EmployeeEntity> fetchAllData() {
		
		return employeeRepository.findAll();
	}

///////////////////////////Fetching Data by ID////////////////// 
	
	@Override
	public EmployeeEntity fetchById(Long empId) throws EmployeeNotFoundException {
		
		 Optional<EmployeeEntity> employee=employeeRepository.findById(empId); //optional will return true or false...and we get based on it
		 
		 if(!employee.isPresent())
		 {
			 throw new EmployeeNotFoundException("Employee data not found in the database");
		 }
		 return employee.get();
	}
	
///////////////////////////Deleting Data by ID/////////////////
	
	@Override
	public void deleteById(Long empId) { 
		
		employeeRepository.deleteById(empId);
		
	}

//////////////////////////Updating Data by ID///////////////////
	
	@Override
	public EmployeeEntity updateById(Long empId, EmployeeEntity employeeEntity) {
		EmployeeEntity empdb=employeeRepository.findById(empId).get();
		
		if(Objects.nonNull(employeeEntity.getEmpName()) && !"".equalsIgnoreCase(employeeEntity.getEmpName())) //if null and empty data then skip that data
		{
			empdb.setEmpName(employeeEntity.getEmpName());//if non null and not blank then we are setting the data
		}
		if(Objects.nonNull(employeeEntity.getEmpDesignation()) && !"".equalsIgnoreCase(employeeEntity.getEmpDesignation()))
		{
			empdb.setEmpDesignation(employeeEntity.getEmpDesignation());;
		}
		if(Objects.nonNull(employeeEntity.getEmpCompany()) && !"".equalsIgnoreCase(employeeEntity.getEmpCompany()))
		{
			empdb.setEmpCompany(employeeEntity.getEmpCompany());
		}
		if(Objects.nonNull(employeeEntity.getEmpLocation()) && !"".equalsIgnoreCase(employeeEntity.getEmpLocation()))
		{
			empdb.setEmpLocation(employeeEntity.getEmpLocation());
		}
		return employeeRepository.save(empdb);
	}

	@Override
	public EmployeeEntity fetchDataByName(String empName) {
		
		return employeeRepository.findByEmpName(empName);
	}

}
