package com.zkteco.demo.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.demo.model.BasicConfig;

@RestController
public class WelcomeCompany {

	@Autowired
	private BasicConfig config;
	
	@RequestMapping("/dynamic-config")
	public Map dynamicConfig() {
		Map map=new HashMap<>();
		map.put("message", config.getMessage());
		map.put("number", config.getNumber());
		map.put("key", config.isValue());
		return map;
	}
}
