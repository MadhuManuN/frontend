package com.zkteco.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.demo.exception.EmployeeNotFoundException;
import com.zkteco.demo.model.EmployeeEntity;
import com.zkteco.demo.service.EmployeeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	//LOGGERS IMPLEMENTATION
	private final Logger logger=LoggerFactory.getLogger(EmployeeController.class);
	
	//////////////////////Saving data in DB(Save API)//////////
	
	@PostMapping("/save")
	public EmployeeEntity saveEmployee(@Valid @RequestBody EmployeeEntity employeeEntity)
	{
		logger.info("Inside save Employee Method");
		return employeeService.saveEmployee(employeeEntity);
	}
	
	//////////////Fetching data from DB/////////////////
	
	@GetMapping("/get/all")
	public List<EmployeeEntity> fetchAllData()
	{
		logger.info("Inside Fetch Employee Method");
		return employeeService.fetchAllData();
	}
	
	///////////////////////////Fetching Data by ID//////////////////
	
	@GetMapping("/get/{id}")
	public EmployeeEntity fetchById(@PathVariable(value = "id") Long empId) throws EmployeeNotFoundException
	{
		logger.info("Inside FetchBy ID Employee Method");
		return employeeService.fetchById(empId);
	}
	
	///////////////////////////Deleting Data by ID/////////////////
	
	@DeleteMapping("/delete/{id}")
	public String deleteById(@PathVariable("id") Long empId)
	{
		employeeService.deleteById(empId);
		return "Data Deleted Sucessufully";
	}
	
	//////////////////////////Updating Data by ID///////////////////
	
	@PutMapping("/update/{id}")
	public EmployeeEntity updateById(@PathVariable(value = "id") Long empId,@RequestBody EmployeeEntity employeeEntity)
	{
		return employeeService.updateById(empId,employeeEntity);
	}
	@GetMapping("/get/name/{name}")
	public EmployeeEntity fetchDataByName(@PathVariable("name") String empName)
	{
		return employeeService.fetchDataByName(empName);
	}
}
