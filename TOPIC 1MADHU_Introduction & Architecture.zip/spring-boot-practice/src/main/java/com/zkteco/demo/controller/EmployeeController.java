package com.zkteco.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	
//	@RequestMapping(value = "/company",method = RequestMethod.GET)
	@GetMapping(value = "/company")
	public String employeeCompany()
	{
		return "I am Working in ZKTECO Compony";
	}

}
