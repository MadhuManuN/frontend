package com.springsframe;

public interface Company {
	
	void designation();
	void work();
	String getQualification();
}
