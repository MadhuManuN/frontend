package com.springsframe;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main_Class {
	
	public static void main(String[] args) {
		
		//xml based and annotatoion based configuration
//		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		 
		ApplicationContext context=new AnnotationConfigApplicationContext(BeanConfig.class);
		Company company=context.getBean(Employee.class);
		
		company.work();
		company.designation();
		System.out.println("Qualification is "+company.getQualification());
	}

}
