package com.springsframe;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.stereotype.Component;


public class Employee implements Company,BeanNameAware {

	private String qualification;
	
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public void designation() {
		System.out.println("Designation :Working as a java Developer");
		
	}

	@Override
	public void work() {
		System.out.println("******************Employee details**************");
		System.out.println("Work :Working in a Banking  project");
		
	}

	@Override
	public String getQualification() {
		// TODO Auto-generated method stub
		return qualification;
	}

	@Override
	public void setBeanName(String name) {
		// TODO Auto-generated method stub
		System.out.println("Set bean name method is called");
	}

	@PostConstruct
	public void postConstruct()
	{
		System.out.println("post Construct method is called");
	}
	
	

}
 