package com.springsframe;

import org.springframework.stereotype.Component;

@Component
public class Manager implements Company {

	private String qualification;
	
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public void work() {
		System.out.println("******************Manager details**************");
		System.out.println("Work: Mainly look over team and assigning work");
		
	}

	@Override
	public void designation() {
		
		System.out.println("Designation : Lead Manager");
		
	}


	@Override
	public String getQualification() {
		// TODO Auto-generated method stub
		return qualification;
	}
	
	
	
	

}
