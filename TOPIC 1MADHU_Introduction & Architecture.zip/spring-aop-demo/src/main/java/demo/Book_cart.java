package demo;

import org.springframework.stereotype.Component;

@Component
public class Book_cart {

	public void checkOut(String status)
	{
		//////Cross cutting concerns
		//logging
		//Authentication logic
		//authorization
		//sanitize the data
		System.out.println("We Are checking out from cart");
	}
}
