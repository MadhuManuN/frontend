package demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main_class {
	
	public static void main(String[] args) {
		
		ApplicationContext context=new AnnotationConfigApplicationContext(BeanConfig.class);
		
		Book_cart cart=context.getBean(Book_cart.class);
		cart.checkOut("Order cancelled");
	}

}
