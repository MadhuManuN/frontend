package demo;

import org.aopalliance.intercept.Joinpoint;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {
	
	@Before( "execution(* demo.Book_cart.checkOut(..))")//any return type
	public void beforeLogging(JoinPoint jp)
	{
//		System.out.println(jp.getSignature());
		String argString=jp.getArgs()[0].toString();
		System.out.println("Before Loggers with arguments :"+argString);
	}

	@After( "execution(* *.*.checkOut(..))")//any returnType,any package,any Class
	public void afterLogging()
	{
		System.out.println("After Loggers");
	}
}
