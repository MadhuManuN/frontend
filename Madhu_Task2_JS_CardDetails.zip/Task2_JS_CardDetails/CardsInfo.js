let movies = [
    {
        id: 1,
        img: "https://th.bing.com/th/id/OIP.tMBVrIbpGVWuHy-4jqgkagHaKj?w=198&h=282&c=7&r=0&o=5&pid=1.7",
        name: "A Beautiful Mind",
        discription: "A Beautiful Mind is a 2001 American biographical drama film directed by Ron Howard. Written by Akiva Goldsman, its screenplay was inspired by Sylvia Nasar's 1998 biography of the mathematician John Nash, a Nobel Laureate in Economics. A Beautiful Mind stars Russell Crowe as Nash, along with Ed Harris, Jennifer Connelly, Paul Bettany, Adam Goldberg, Judd Hirsch, Josh Lucas, Anthony Rapp, and Christopher Plummer in supporting roles. The story begins in Nash's days as a graduate student at Princeton University. Early in the film, Nash begins to develop paranoid schizophrenia and endures delusional episodes while watching the burden his condition brings on his wife Alicia and friends."
    },
    {
        id: 2,
        img: "https://th.bing.com/th/id/OIP.ZzTqQqklhn3o2huZS_Fh0AHaEK?w=245&h=180&c=7&r=0&o=5&pid=1.7",
        name: " The Shawshank Redemption",
        discription: "The Shawshank Redemption is a 1994 American drama film written and directed by Frank Darabont, based on the 1982 Stephen King novella Rita Hayworth and Shawshank Redemption. The film tells the story of banker Andy Dufresne (Tim Robbins), who is sentenced to life in Shawshank State Penitentiary for the murders of his wife and her lover, despite his claims of innocence. Over the following two decades, he befriends a fellow prisoner, contraband smuggler Ellis red Redding (Morgan Freeman), and becomes instrumental in a money laundering operation led by the prison warden Samuel Norton (Bob Gunton). William Sadler, Clancy Brown, Gil Bellows, and James Whitmore appear in supporting roles"
    },
    {
        id: 3,
        img: "https://th.bing.com/th/id/OIP.NN9rKH-vZbFgtH4FuoW7OwHaLH?w=122&h=183&c=7&r=0&o=5&pid=1.7",
        name: "The Dark Knight",
        discription: "The Dark Knight is a 2008 superhero film directed by Christopher Nolan from a screenplay he co-wrote with his brother Jonathan. Based on the DC Comics superhero, Batman, it is the sequel to Batman Begins (2005) and the second installment in The Dark Knight Trilogy. The plot follows the vigilante Batman, police lieutenant James Gordon, and district attorney Harvey Dent, who form an alliance to dismantle organized crime in Gotham City. Their efforts are derailed by the Joker, an anarchistic mastermind who seeks to test how far Batman will go to save the city from chaos. The ensemble cast includes Christian Bale, Michael Caine, Heath Ledger, Gary Oldman, Aaron Eckhart, Maggie Gyllenhaal, and Morgan Freeman."
    },
    {
        id: 4,
        img: "https://th.bing.com/th/id/OIP.DEdQbkF9LwphPQfPsXqfzAHaLH?w=121&h=182&c=7&r=0&o=5&pid=1.7",
        name: "The Godfather",
        discription: "The Godfather is a 1972 American crime film[2] directed by Francis Ford Coppola, who co-wrote the screenplay with Mario Puzo, based on Puzo's best-selling 1969 novel of the same title. The film stars Marlon Brando, Al Pacino, James Caan, Richard Castellano, Robert Duvall, Sterling Hayden, John Marley, Richard Conte, and Diane Keaton. It is the first installment in The Godfather trilogy, chronicling the Corleone family under patriarch Vito Corleone (Brando) from 1945 to 1955. It focuses on the transformation of his youngest son, Michael Corleone (Pacino), from reluctant family outsider to ruthless mafia boss."
    }
]

let parent = document.getElementById("parent")
movies.map(({img,id,name})=>{
    return parent.innerHTML +=
    `
<div class="child">
<button onclick="buttonClickHandler(${id})" id="fetchBtn" >
        <img src=${img}>
        <h3>${name}</h3>
        
</button>
    </div>
`
})

let btn = document.getElementById("btn");
let parent2 = document.getElementById("parent2");
function buttonClickHandler(id) {
    parent2.style.display='block';
    btn.style.display='block'
    for(let i=0;i<movies.length;i++){
        if(movies[i].id===id)
        {
            parent2.innerHTML=
            `
            <div class="child1">
                    <h3>${movies[i].name}</h3>
                    <p>${movies[i].discription}</p>
            </div>
            `  
        }
    }
}

function displayBtn(){
    window.location.reload();
}



// // for (let { img, name,id,discription } of movies) {
//     for(let i=0;i<movies.length;i++){
//         parent.innerHTML +=
//             `
//         <div class="child">
//         <button onclick="buttonClickHandler()" id="fetchBtn">
//                 <img src=${movies[i].img}>
//                 <h3>${movies[i].name}</h3>
//                 <h1>${movies[i].id}</h1>
                
//         </button>
//             </div>
           
//         `
//     }
// parent.innerHTML=movies.map(getData);
// function getData({img,id,name}){
//     return `
//     <div class="child">
//     <button onclick="buttonClickHandler()" id="fetchBtn" >
//             <img src=${img}>
//             <h3>${name}</h3>
//             <h1>${id}</h1>
            
//     </button>
//         </div>`
// }