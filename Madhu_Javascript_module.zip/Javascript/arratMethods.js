// const cart = ["apple", "banana", "pear"];

// // A function which returns the last item of a given array
// function returnLast(arr) {
//   return arr.at(-1);
// }

// // Get the last item of our array 'cart'
// const item1 = returnLast(cart);
// console.log(item1); // 'pear'

// // Add an item to our 'cart' array
// cart.push("orange");
// const item2 = returnLast(cart);
// console.log(item2)

//                             ///Comparing methods(at)


// const colors = ["red", "green", "blue"];
// const lengthWay = colors[colors.length - 2];
// console.log(lengthWay); 

// // Using slice() method. Note an array is returned
// const sliceWay = colors.slice(-2, -1);
// console.log(sliceWay[0]); 

// // Using at() method
// const atWay = colors.at(-2);
// console.log(atWay); 

//                            //Concatenating two arrays
// let str=["a",'b',"c"];
// let num=[1,2,3,4];
// let alphaNum=str.concat(num);

// let alpNum=str.concat([1,[2,3]])

// console.log(alphaNum);
// console.log(alpNum)

// // const num1 = [1, 2, 3];
// // const num2 = [4, 5, 6];
// // const num3 = [7, 8, 9];

// // const numbers = num1.concat(num2, num3);

// // console.log(numbers);

// const num1 = [[1]];
// const num2 = [2, [3]];

// const numbers = num1.concat(num2);

// console.log(numbers);
// // results in [[1], 2, [3]]

// // modify the first element of num1
// num1[0].push(4);

// console.log(numbers);

//                             //Using copyWithin()

// console.log([1, 2, 3, 4, 5].copyWithin(-2));
// // [1, 2, 3, 1, 2]

// console.log([1, 2, 3, 4, 5].copyWithin(0, 3));
// // [4, 5, 3, 4, 5]

// console.log([1, 2, 3, 4, 5].copyWithin(0, 3, 4));
// // [4, 2, 3, 4, 5]

// console.log([1, 2, 3, 4, 5].copyWithin(-2, -3, -1));


//                              //entries() method 
// const array1 = ['a', 'b', 'c'];

// const iterator1 = array1.entries();

// console.log(iterator1.next().value);
// // Expected output: Array [0, "a"]

// console.log(iterator1.next().value);

// console.log(iterator1.next().value);

// console.log("---------------------------------------------------------------------------")

// const a = ["a", "b", "c"];

// for (const [index,element] of a.entries()) {
//   console.log(index,element);
// }

//                                       //every() method

// const isBelow=currentVal=>currentVal<40;

// const arr=[1,20,30,36,33,39];
// console.log(arr.every(isBelow));

// function isBigEnough(element, index, array) {
//     return element >= 10;
//   }
//   console.log([12, 5, 8, 130, 44].every(isBigEnough))
//   console.log( [12, 54, 18, 130, 44].every(isBigEnough))


//                                            //Filter() method

// const words = ['spray', 'limit', 'elite', 'exuberant', 'destruction', 'present'];

// const result = words.filter(word => word.length > 6);

// console.log(result);

// const array = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];

// function isPrime(num){
//     for(let i=2;i<num;i++){
//         if(num%i==0) return false;
//     }
//     return num>1;
// }


// console.log(array.filter(isPrime));


// const arr = [
//     { id: 15 },
//     { id: -1 },
//     { id: 0 },
//     { id: 3 },
//     { id: 12.2 },
//     {},
//     { id: null },
//     { id: NaN },
//     { id: "undefined" },
//   ];
  
//   let invalidEntries = 0;

//   function filterById(item){
//     if(Number.isFinite(item.id) && item.id !==0) return true;
//     invalidEntries++;
//     return false;
//   }
//   let arrById=arr.filter(filterById);

//   console.log("filtered array",arrById);

//   console.log("invalidEntries:", invalidEntries)

  
//   const fruits = ["apple", "banana", "grapes", "mango", "orange"];

//   function filterItems(item,search){
//     return item.filter((fruit)=>{
//         return fruit.toLowerCase().includes(search.toLowerCase());
//     })
//   }


//   console.log(filterItems(fruits,"ng"));
//   console.log(filterItems(fruits,"ap"));

//                                                          //find() method
//   const inventory = [
//     { name: "apples", quantity: 2 },
//     { name: "bananas", quantity: 0 },
//     { name: "cherries", quantity: 5 },
//   ];
  
//   const result1 = inventory.find(({ name }) => name === "bananas");
  
//   console.log(result1); // { name: 'cherries', quantity: 5 }


//   function isPrime(element, index, array) {
//     let start = 2;
//     while (start <= Math.sqrt(element)) {
//       if (element % start++ < 1) {
//         return false;
//       }
//     }
//     return element > 1;
//   }
  
//   console.log([4, 6, 9,11, 12].find(isPrime)); 
//   console.log([4,3, 5, 8, 12].find(isPrime));


//                                                  //from() method

// console.log(Array.from("madhu"));

// console.log(Array.from([2,4,6,8],x=>x+x))

// //Array from a Set

// const set = new Set(["foo", "bar", "baz", "foo", "bar"]);
// console.log(Array.from(set))



                                                       //map() method
// const kvArray = [
//     { key: 1, value: 10 },
//     { key: 2, value: 20 },
//     { key: 3, value: 30 },
//   ];
  
//   const reformattedArray = kvArray.map(({ key, value }) => ({ [key]: value }));
  
//   console.log(reformattedArray); // [{ 1: 10 }, { 2: 20 }, { 3: 30 }]
//   console.log(kvArray);

                                                         //reduce() method
console.log([15, 16, 17, 18, 19].reduce(
    (accumulator, currentValue) => accumulator + currentValue,
    15,
  ))//100

  const objects = [{ x: 1 }, { x: 2 }, { x: 3 }];
const sum = objects.reduce(
  (accumulator, currentValue) => accumulator + currentValue.x,
  10,
);

console.log(sum);//16


const flattened = [
    [0, 1],
    [2, 3],
    [4, 5],
  ].reduce((accumulator, currentValue) => accumulator.concat(currentValue), []);
console.log("flattened data is",flattened);


const names = ["Alice", "Bob", "Tiff", "Bruce", "Alice"];

const countedNames = names.reduce((allNames, name) => {
    console.log(allNames[name] ?? 0)
  const currCount = allNames[name] ?? 0;
  return {
    ...allNames,
    [name]: currCount + 1,
  };
}, {});
console.log(countedNames)