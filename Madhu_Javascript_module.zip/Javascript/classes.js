class Human{
    gender="female";

    printGender=()=>{
        console.log(this.gender);
    }
}

class Person extends Human{
    name="Madhu";
    gender='male'
    printperson=()=>{
        console.log(this.name);
    }
}

                 //////spread operator
const person=new Person();
person.printperson();
person.printGender();

const person1={
    name:'manu'
};
const newPerson={
    ...person1,
    age:'25'
};
console.log(newPerson)

            ///////////////Rest parameters
const filter=(...args)=>{
    return args.filter(res=>res%2)
}
console.log(filter(2,4,6,8,7,9,3))


            ///////////////////////object destructuring
const person2={
    name:"madhu"
}
const secPerson=person2;
person2.name="jagnya";
console.log(secPerson)

const person3={
    name:"madhu"
}
const secPerson1={
    ...person3
}
person3.name="jagnya";
console.log(secPerson1)



//array Functions
let numbers=[1,2,3,4,5];
let doubleNum=numbers.map((num)=>{
    return num*2;
})
console.log(numbers);
console.log(doubleNum);