//Manually hand-rolling the iterator

let arr=["a",'b',"c","d"];
let arrItt=arr[Symbol.iterator]();
console.log(arrItt.next().value);
console.log(arrItt.next().value);
console.log(arrItt.next().value);
console.log(arrItt.next().value);

//Handling strings and string arrays with the same function

function stringItterable(str){
    console.log(typeof str[Symbol.iterator])
    if(typeof str[Symbol.iterator] !="function"){
        console.log(str,"it is notiterable")
    }
    for (const iterator of str) {
        console.log(iterator);
    }
}

stringItterable("madhu");
stringItterable(["a","b","c"]);
stringItterable(1234);
