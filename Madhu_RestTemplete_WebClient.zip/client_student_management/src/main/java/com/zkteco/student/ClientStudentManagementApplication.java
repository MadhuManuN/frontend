package com.zkteco.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientStudentManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientStudentManagementApplication.class, args);
	}

}
