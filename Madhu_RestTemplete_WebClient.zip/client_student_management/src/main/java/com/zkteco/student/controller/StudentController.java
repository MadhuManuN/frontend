package com.zkteco.student.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.student.dto.ClientDto;
import com.zkteco.student.dto.ResultDto;
import com.zkteco.student.service.StudentService;

import jakarta.validation.Valid;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService service;
	
	@PostMapping("/")
	public Mono<ResultDto> postStudDetails(@Valid @RequestBody ClientDto clientDto) {
		return service.postStudDetails(clientDto);
	}
	@GetMapping("/list")
	public Flux<ResultDto> getStudDetails() {
		return service.getStudDetails();
	}
	@GetMapping("/{id}")
	public ResultDto getStudById(@PathVariable(value = "id") String id) {
		return service.getStudById(id);
	}
	
	@DeleteMapping("/{id}")
	public Mono<ResultDto> deleteStudById(@PathVariable("id") String id) {
		return service.deleteStudById(id);
	}
	@PutMapping("/{id}")
	public Mono<ResultDto> updateStudById(@PathVariable("id") String id, @RequestBody ClientDto clientDto) {
		return service.updateStudById(id, clientDto);
	}

}
