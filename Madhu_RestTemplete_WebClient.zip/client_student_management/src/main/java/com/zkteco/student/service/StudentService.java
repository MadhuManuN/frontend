package com.zkteco.student.service;

import org.springframework.stereotype.Service;

import com.zkteco.student.dto.ClientDto;
import com.zkteco.student.dto.ResultDto;

import jakarta.validation.Valid;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public interface StudentService {

	public Mono<ResultDto> postStudDetails(@Valid ClientDto clientDto);

	public Flux<ResultDto> getStudDetails();

	public ResultDto getStudById(String id);

	public Mono<ResultDto> deleteStudById(String id);

	public Mono<ResultDto> updateStudById(String id, ClientDto clientDto);

}
