const arr1 = [{name: "Madhu", age: "27",email:"madhu@gmail.com",phoneNo:"+91-974197542"}, {name: "jagnya", age: "24",email:"jagnya@gmail.com",phoneNo:"+91-974167542"},
{name: "srinivas", age: "26",email:"seenu@gmail.com",phoneNo:"+91-9894167542"},{name: "naveen", age: "24",email:"naveen@gmail.com",phoneNo:"+91-996167542"},
{name: "karthik", age: "23",email:"karthi@gmail.com",phoneNo:"+91-987167542"},{name: "shubam", age: "26",email:"shubam@gmail.com",phoneNo:"+91-874667542"}];

const arr2 = [{name: "Manu", age: "23",email:"manu@gmail.com",phoneNo:"+91-984167542"}, {name: "shivaraj", age: "30",email:"shivu@gmail.com",phoneNo:"+91-789167542"},
{name: "subhash", age: "28",email:"subbu@gmail.com",phoneNo:"+91-874167542"},{name: "lokesh", age: "30",email:"loki@gmail.com",phoneNo:"+91-697167542"},
{name: "Madhu", age: "27",email:"madhu123@gmail.com",phoneNo:"+91-974167542"},{name: "srinivas", age: "26",email:"seenu12@gmail.com",phoneNo:"+91-987677542"}];

const map = new Map();

// arr1.concat(arr2) === [...arr1, ...arr2]
const arr3 = [...arr1, ...arr2];
console.log(arr3)
// for ... of, iterator array
for(const obj of arr3) {
  if(!map.has(obj.name)) {
   
    map.set(obj.name, obj); // add
  } else {
    map.set(obj.name, {
      ...map.get(obj.name), // update
      ...obj,
    });
  }
}
// get new merged unqiue array
const mergedData = [...map.values()];
let mergedData1=JSON.stringify(mergedData,null,4);

console.log( mergedData1);

let refresh=document.getElementById("refresh");
let fetchBtn = document.getElementById("fetchbtn");
fetchBtn.addEventListener('click', buttonClickHandler);

function buttonClickHandler() {
  fetchBtn.style.display='none';
  refresh.style.display='block';
    console.log("hello")
    let tbody = document.getElementById("tbody");
    let Slno=0;
    for(let i=0;i<mergedData.length;i++){
        tbody.innerHTML +=
        `<tr>
        <td>${++Slno}</td>
        <td>${mergedData[i].name}</td>
        <td>${mergedData[i].age}</td>
        <td>${mergedData[i].email}</td>
        <td>${mergedData[i].phoneNo}</td>
    </tr>`
    }
}

function refreshData(){
  window.location.reload();
}