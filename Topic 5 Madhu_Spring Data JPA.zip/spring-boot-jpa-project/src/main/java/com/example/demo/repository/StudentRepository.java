package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Student;

import jakarta.transaction.Transactional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long>{

	public List<Student> findByFirstName(String firstName);
	
	public List<Student> findByFirstNameContaining(String name);
	
	public List<Student> findByGuardianName(String guardianName);
	
	//Jpql query 
	
	@Query("select s from Student s where s.emailId= ?1")
	public Student getStudentByEmailAddress(String emailId);
	
	@Query("select s.firstName from Student s where s.emailId= ?1")
	public String getStudentFirstNameByEmailAddress(String emailId);
	
	//native query
	
	@Query(value = "SELECT * FROM student_table s where s.Email_Id= ?1 ",
			nativeQuery = true
			)
	public Student getStudentByEmailAddressNative(String emailId);
	
	

	//native Named Param
	
	@Query(value = "SELECT * FROM student_table s where s.Email_Id= :emailId ",
			nativeQuery = true
			)
	public Student getStudentByEmailAddressNativeNamedParam(@Param("emailId") String emailId);
	
	
	@Modifying
	@Transactional
	@Query(value = "update student_table set First_Name=?1 where Email_Id= ?2 ",
			nativeQuery = true
			)
	public int updateStudentNameByEmailId(String firstName,String emailId);
}
