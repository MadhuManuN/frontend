package com.example.demo.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Guardian;
import com.example.demo.entity.Student;

@SpringBootTest
class StudentRepoTest {

	@Autowired
	private StudentRepository repository;

	public void saveStudentGuardian() {
		Guardian guardian = Guardian.builder().guardianName("Subhash").guardianMobile("7489715")
				.guardianEmail("sub@gmail.com").build();

		Student student = Student.builder().firstName("Manoj").LastName("M N").emailId("manoj124@gmail.com")
				.guardian(guardian).build();
		repository.save(student);
	}

	public void printAllStudents() {
		List<Student> studentList=repository.findAll();
		System.out.println("Students List"+ studentList);
	}
	

	public void printStudentByFirstName()
	{
		List<Student> students=repository.findByFirstName("Madhu");
		
		System.out.println("Student Name is :"+students);
	}
	

	public void printStudentByFirstNameContains()
	{
		List<Student> students2=repository.findByFirstNameContaining("Mad");
		
		System.out.println("Student1 Name is :"+students2);
	}

	public void printStudentByGuardian()
	{
		List<Student> students3=repository.findByGuardianName("Rajesh");
		
		System.out.println("Student1 Name is :"+students3);
	}


	public void getStudentByEmailId()
	{
	Student	students4=repository.getStudentByEmailAddress("manoj124@gmail.com");	
	
	System.out.println("Student details is:"+students4);
	}
	
	
	public void getStudentFirstNameByEmailId()
	{
	String name=repository.getStudentFirstNameByEmailAddress("manoj124@gmail.com");	
	
	System.out.println("Student details is:"+name);
	}
	
	/////Native Query
	public void getStudentByEmailIdNative()
	{
	Student	students4=repository.getStudentByEmailAddressNative("manoj124@gmail.com");	
	
	System.out.println("Student details is:"+students4);
	}
	
	//Native Named Param

	public void getStudentByEmailIdNativeNamedParam()
	{
	Student	students4=repository.getStudentByEmailAddressNativeNamedParam("madhu1234@gmail.com");	
	
	System.out.println("Student details is:"+students4);
	}
	
	@Test
	public void updateStudentByEmailId()
	{
	repository.updateStudentNameByEmailId("Madhu manu", "madhu1234@gmail.com");
	
	
	}
}
