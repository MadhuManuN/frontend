package com.zkteco.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Employee")
public class EmployeeEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long empId;
	
	@Column(name = "EMP_NAME")
	private String empName;
	@Column(name = "EMP_DESIGNATION")
	private String empDesignation;
	@Column(name = "EMP_COMPANY")
	private String empCompany;
	@Column(name = "EMP_LOCATION")
	private String empLocation;
	
	
	public EmployeeEntity() {
		super();
	}
	
	public EmployeeEntity(Long empId, String empName, String empDesignation, String empCompany, String empLocation) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empDesignation = empDesignation;
		this.empCompany = empCompany;
		this.empLocation = empLocation;
	}
	public Long getEmpId() {
		return empId;
	}
	public void setEmpId(Long empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public String getEmpCompany() {
		return empCompany;
	}
	public void setEmpCompany(String empCompany) {
		this.empCompany = empCompany;
	}
	public String getEmpLocation() {
		return empLocation;
	}
	public void setEmpLocation(String empLocation) {
		this.empLocation = empLocation;
	}

	@Override
	public String toString() {
		return "EmployeeEntity [empId=" + empId + ", empName=" + empName + ", empDesignation=" + empDesignation
				+ ", empCompany=" + empCompany + ", empLocation=" + empLocation + "]";
	}
	

}
