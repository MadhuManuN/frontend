package com.zkteco.demo.service;

import java.util.List;

import com.zkteco.demo.model.EmployeeEntity;

public interface EmployeeService {

	public EmployeeEntity saveEmployee(EmployeeEntity employeeEntity);

	public List<EmployeeEntity> fetchAllData();

	public EmployeeEntity fetchById(Long empId);

	public void deleteById(Long empId);

	public EmployeeEntity updateById(Long empId, EmployeeEntity employeeEntity);

}
