package com.zkteco.task.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.zkteco.task.entity.Department;
import com.zkteco.task.entity.Designation;
import com.zkteco.task.entity.Employee;
import com.zkteco.task.entity.Result;

import com.zkteco.task.service.EmployeeService;

import jakarta.servlet.http.HttpServletRequest;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;

@WebMvcTest(EmployeeController.class)
class EmployeeControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private EmployeeService employeeService;
	
	HttpServletRequest request;
	
	private List<Employee> employees=new ArrayList<>();
	private List<Employee> employees1=new ArrayList<>();
	
	Result result=null;
	
	private Employee employee;
	@BeforeEach
	void setUp() throws Exception {
		
		Department department=Department.builder()
				.deptId("1")
				.deptName("R&D")
				.deptCode("abc123")
				.createDate("2023-03-15")
				.updateDate("2023-03-22")
				.build();
		Designation designation=Designation.builder()
				.desigId("1")
				.desigName("java")
				.desigCode("pqr123")
				.createDate("2023-03-15")
				.updateDate("2023-03-22")
				.build();
		employee=Employee.builder()
				.employeeId("1")
				.firstName("madhu")
				.lastName("manu")
				.gender("M")
				.employeeEmailId("madhu123@gmail.com")
				.phoneNumber("+91-9874561231")
				.password("Wypuyh265")
				.dateOfBirth("1/06/2023")
				.profilePhoto(true)
				.createDate("2023-03-15")
				.updateDate("2023-03-21")
				.department(department)
				.designation(designation)
				.build();
		result=new Result("I100", "Success", employee);
		employees.add(employee);
	}

	@Test
	void saveEmployee() throws Exception {
		Department department=Department.builder()
				.deptId("1")
				.deptName("R&D")
				.deptCode("abc123")
				.createDate("2023-03-15")
				.updateDate("2023-03-22")
				.build();
		Designation designation=Designation.builder()
				.desigId("1")
				.desigName("java")
				.desigCode("pqr123")
				.createDate("2023-03-15")
				.updateDate("2023-03-22")
				.build();
		Employee inputEmployee=Employee.builder()
				.employeeId("1")
				.firstName("madhu")
				.lastName("manu")
				.gender("M")
				.employeeEmailId("madhu123@gmail.com")
				.phoneNumber("+91-9874561231")
				.password("Wypuyh265")
				.dateOfBirth("1/06/2023")
				.profilePhoto(true)
				.createDate("2023-03-15")
				.updateDate("2023-03-21")
				.department(department)
				.designation(designation)
				.build();
		Mockito.when(employeeService.saveEmployee(inputEmployee, request)).thenReturn(result);
		int status =mockMvc.perform(MockMvcRequestBuilders.post("/api/employee")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\r\n"
						+ "    \"employeeId\":2,\r\n"
						+ "    \"firstName\":\"Manoj\",\r\n"
						+ "    \"lastName\":\"manu\",\r\n"
						+ "    \"gender\":\"M\",\r\n"
						+ "    \"employeeEmailId\":\"manoj296@gmail.com\",\r\n"
						+ "    \"phoneNumber\":\"+91-9878998952\",\r\n"
						+ "    \"password\":\"Wypuyh265\",\r\n"
						+ "    \"dateOfBirth\":\"1/06/2023\",\r\n"
						+ "    \"profilePhoto\":true,\r\n"
						+ "    \"createDate\":\"2023-03-15\",\r\n"
						+ "    \"updateDate\":\"2023-03-24\",\r\n"
						+ "    \"department\":{\r\n"
						+ "   \"deptId\":1,\r\n"
						+ "   \"deptCode\":\"abc123\",\r\n"
						+ "   \"deptName\":\"R&D\",\r\n"
						+ "   \"createDate\":\"2023-03-15\",\r\n"
						+ "   \"updateDate\":\"2023-03-22\"\r\n"
						+ "},\r\n"
						+ "\"designation\":{\r\n"
						+ "   \"desigId\":1,\r\n"
						+ "   \"desigCode\":\"pqr123\",\r\n"
						+ "   \"desigName\":\"java\",\r\n"
						+ "   \"createDate\":\"2023-03-15\",\r\n"
						+ "   \"updateDate\":\"2023-03-22\"\r\n"
						+ "}\r\n"
						+ "}")).andReturn().getResponse().getStatus();
		assertEquals(200, status);
//		.andExpect(MockMvcResultMatchers.status().isOk())
//		.andExpect(jsonPath("$",hasSize()))
//        .andExpect(jsonPath("$.firstName", is("madhu")));
	}
	@Test
	void saveEmployeeData() throws Exception {
		Department department=Department.builder()
				.deptId("1")
				.deptName("R&D")
				.deptCode("abc123")
				.createDate("2023-03-15")
				.updateDate("2023-03-22")
				.build();
		Designation designation=Designation.builder()
				.desigId("1")
				.desigName("java")
				.desigCode("pqr123")
				.createDate("2023-03-15")
				.updateDate("2023-03-22")
				.build();
		Employee inputEmployee=Employee.builder()
				.employeeId("1")
				.firstName("madhu")
				.lastName("manu")
				.gender("M")
				.employeeEmailId("madhu123@gmail.com")
				.phoneNumber("+91-9874561231")
				.password("Wypuyh265")
				.dateOfBirth("1/06/2023")
				.profilePhoto(true)
				.createDate("2023-03-15")
				.updateDate("2023-03-21")
				.department(department)
				.designation(designation)
				.build();
		ObjectMapper mapper=new ObjectMapper();
		String bookJson=mapper.writeValueAsString(inputEmployee);
		Mockito.when(employeeService.saveEmployee(inputEmployee, request)).thenReturn(result);
		int status =mockMvc.perform(MockMvcRequestBuilders.post("/api/employee")
				.contentType(MediaType.APPLICATION_JSON)
				.content(bookJson)).andReturn().getResponse().getStatus();
		assertEquals(200, status);

	}
	@Test
	void saveEmployeeData1() throws Exception {
		Department department=Department.builder()
				.deptId("1")
				.deptName("R&D")
				.deptCode("abc123")
				.createDate("2023-03-15")
				.updateDate("2023-03-22")
				.build();
		Designation designation=Designation.builder()
				.desigId("1")
				.desigName("java")
				.desigCode("pqr123")
				.createDate("2023-03-15")
				.updateDate("2023-03-22")
				.build();
		Employee inputEmployee=Employee.builder()
				.employeeId("1")
				.firstName("madhu")
				.lastName("manu")
				.gender("M")
				.employeeEmailId("madhu123@gmail.com")
				.phoneNumber("+91-9874561231")
				.password("Wypuyh265")
				.dateOfBirth("1/06/2023")
				.profilePhoto(true)
				.createDate("2023-03-15")
				.updateDate("2023-03-21")
				.department(department)
				.designation(designation)
				.build();
		Result result2=new Result("I100", "Success", inputEmployee);
		employees1.add(employee);
		ObjectMapper mapper=new ObjectMapper();
		String bookJson=mapper.writeValueAsString(inputEmployee);
		Mockito.when(employeeService.saveEmployee(inputEmployee, request)).thenReturn(result2);
		int status =mockMvc.perform(MockMvcRequestBuilders.post("/api/employee")
				.contentType(MediaType.APPLICATION_JSON)
				.content(bookJson)).andReturn().getResponse().getStatus();
		assertEquals(200, status);
		assertEquals(result.getData(), result2.getData());

	}
	
	@Test
	public void fetchEmployeeById() throws Exception {
		Mockito.when(employeeService.fetchById(employee.getEmployeeId(), request)).thenReturn(result);
		int status =mockMvc.perform(MockMvcRequestBuilders.get("/api/employee/1")
				.contentType(MediaType.APPLICATION_JSON)).andReturn().getResponse().getStatus();
		assertEquals(200, status);
		assertEquals("manu", employee.getLastName());
				
	}
	
	@Test
	public void getAllRecords_success() throws Exception{
		String name="madhu";
		Mockito.when(employeeService.fetchAllData()).thenReturn(employees);
		mockMvc.perform(MockMvcRequestBuilders
	            .get("/api/employee/all")
	            .contentType(MediaType.APPLICATION_JSON))
//				.andReturn().getResponse().getStatus();
//		assertEquals(200, status);
//		assertEquals(name, employees.get(0).getFirstName());
	            .andExpect(status().isOk())
	            .andExpect(jsonPath("$",hasSize(1)))
	            .andExpect(jsonPath("$[0].firstName", is("madhu")));
	}
	@Test
	public void getAllRecords() throws Exception{
		Mockito.when(employeeService.fetchAllData()).thenReturn(employees);
		int status =mockMvc.perform(MockMvcRequestBuilders
	            .get("/api/employee/all")).andReturn().getResponse().getStatus();
		assertEquals(200, status);
	}

}
