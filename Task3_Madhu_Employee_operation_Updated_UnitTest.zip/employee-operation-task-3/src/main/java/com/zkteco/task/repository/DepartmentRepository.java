package com.zkteco.task.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.zkteco.task.entity.Department;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, String>{
//	
//	@Query(value = "SELECT d from Department d where d.department_name= ?1",nativeQuery = true)
//	public Department getDepartmentByDeptName(String deptName);
//	
      public Department findByDeptName(String deptName);
      
      public Department findByDeptCode(String deptCode);

}
