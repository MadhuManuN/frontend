package com.zkteco.task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeOperationTask3Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeOperationTask3Application.class, args);
	}

}
