package com.zkteco.task.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Department;
import com.zkteco.task.entity.Result;

import jakarta.validation.Valid;

@Service
public interface DepartmentService {

	public Result saveDepartment(@Valid Department department);

	public Result deleteById(String deptId);

	public List<Result> saveAllData(@Valid List<Department> department);

	public List<Department> fetchAllData();

	public Result fetchById(String deptId);

	public Result updateById(String deptId, Department department);

}
