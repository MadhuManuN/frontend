package com.zkteco.task.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Result;
import com.zkteco.task.entity.Employee;
import com.zkteco.task.exception.ResourceNotFoundException;

import jakarta.validation.Valid;


@Service
public interface EmployeeService {
	
	
	public Result saveEmployee(@Valid Employee employee);
	
	public List<Result> saveAllData(@Valid List<Employee> employee);
	
	public List<Employee> fetchAllData();
	
	public Result fetchById(String employeeId) throws ResourceNotFoundException;
	
	public Result fetchByEmail(String employeeEmailId) throws ResourceNotFoundException;
	
	public Result fetchByPhone(String phoneNumber) throws ResourceNotFoundException;
	
	public Result deleteById(String employeeId);
	
	public Result updateById(String employeeId, Employee employee);
	
	public List<Employee> fetchByDate(String fromDate, String toDate) throws ResourceNotFoundException;

}
