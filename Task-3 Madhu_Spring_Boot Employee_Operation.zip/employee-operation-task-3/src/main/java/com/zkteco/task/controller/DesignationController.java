package com.zkteco.task.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.task.entity.Designation;
import com.zkteco.task.entity.Result;
import com.zkteco.task.exception.ResourceNotFoundException;
import com.zkteco.task.service.DesignationService;

import jakarta.validation.Valid;

@RestController
public class DesignationController {
	@Autowired
	private DesignationService designationService;
	
	private final Logger logger = LoggerFactory.getLogger(DepartmentController.class);
	
	@PostMapping("/designation")
	public Result saveDesignation(@Valid @RequestBody Designation designation) {
		logger.info("Inside save Department Method");
		return designationService.saveDepartment(designation);
	}
	
	@PostMapping("/designation/batch")
	public List<Result> saveMultipleData(@Valid @RequestBody List<Designation> designation) {
		return designationService.saveAllData(designation);
	}
	
	@GetMapping("/designation/all")
	public List<Designation> fetchAllData() {
		logger.info("Inside Fetch Designation Method");
		return designationService.fetchAllData();
	}
	
	@GetMapping("/designation/{id}")
	public Result fetchById(@PathVariable(value = "id") String desigId) throws ResourceNotFoundException {
		logger.info("Inside FetchBy ID Designation Method");
		return designationService.fetchById(desigId);
	}
	
	@DeleteMapping("/designation/{id}")
	public Result deleteById(@PathVariable("id") String desigId) throws ResourceNotFoundException {
		logger.info("Inside Delete by ID Method");

		return designationService.deleteById(desigId);
	}
	
	@PutMapping("/designation/{id}")
	public Result updateById(@PathVariable(value = "id") String desigId, @RequestBody Designation designation) {
		logger.info("Inside Update By ID Designation Method");
		return designationService.updateById(desigId, designation);
	}

}
