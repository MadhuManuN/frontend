package com.zkteco.task.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Department;
import com.zkteco.task.entity.Result;
import com.zkteco.task.repository.DepartmentRepository;

import jakarta.validation.Valid;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentRepository repository;

	public Result validationMandatory(Department department) {
		String name = department.getDeptName();
		String code = department.getDeptCode();

		if (!name.isEmpty()) {
			if (name.length() >= 50) {
				return new Result("E100", "Department Name Too Lengthy", "");
			}
		} else {
			return new Result("E100", "Department Name cannot be empty", "");
		}
		if (!code.isEmpty()) {
			if (code.length() >= 30) {
				return new Result("E100", "Department code Too Lengthy", "");
			}
		} else {
			return new Result("E100", "Department code cannot be empty", "");
		}
		return null;

	}

	public Result validation(Department department) {
		Optional<Department> departmentDbData = repository.findById(department.getDeptId());
		Department departmentDbData1 = repository.findByDeptName(department.getDeptName());
		Department departmentDbData2 = repository.findByDeptCode(department.getDeptCode());
		Department departmentResponse = new Department();

		if (department.getDeptId().length() != 0) {
			if (department.getDeptId().length() >= 4) {
				Result result = new Result("E100", "Invalid: Department Id Length is Big", "Check ID Length");
				return result;
			}
		} else {
			Result result = new Result("E100", "Department Id cannot be empty", "Check ID");
			return result;
		}
		Result resultMand = validationMandatory(department);
		if (resultMand != null)
			return resultMand;

		if (departmentDbData.isEmpty()) {
			if (departmentDbData1 == null) {
				if (departmentDbData2 == null) {
					departmentResponse = repository.save(department);
					Result result = new Result("I100", "Department Data Saved in the DataBase", departmentResponse);
					return result;
				}
				return new Result("E100", "Department code is already registered", "");
			}
			return new Result("E100", "Department Name is already registered", "");
		}
		return new Result("E100", "This Department Is Already Registered", "");

	}

	@Override
	public Result saveDepartment(@Valid Department department) {

		if (department != null) {
			Result result1 = validation(department);
			return result1;
		}
		return new Result("E100", "Please send Department details", "");
	}

	@Override
	public List<Result> saveAllData(@Valid List<Department> department) {
		List<Result> results = new ArrayList<>();
		for (Department departmentData : department) {
			Result result1 = validation(departmentData);
			results.add(result1);
		}
		return results;
	}

	@Override
	public List<Department> fetchAllData() {
		return repository.findAll();
	}

	@Override
	public Result fetchById(String deptId) {
		Result result = new Result();
		Optional<Department> department = repository.findById(deptId);
		// .orElseThrow(()->new ResourceNotFoundException("User Not found for this is id
		// "+userId));
		if (!department.isEmpty()) {
			result.setCode("I100");
			result.setData(department.get());
			result.setMessage("Success");
		} else {
			result.setCode("E100");
			result.setMessage("Department not exist");
		}
		return result;
	}

	@Override
	public Result deleteById(String deptId) {
		Result result = new Result();
		Optional<Department> department = repository.findById(deptId);
		if (!department.isEmpty()) {
			result.setCode("");
			result.setData("");
			result.setMessage("Deleted Succesfully");
			repository.deleteById(deptId);
		} else {
			result.setCode("E100");
			result.setMessage("data not exist");
		}
		return result;
	}

	@Override
	public Result updateById(String deptId, Department department) {
		Result result;
		Department departmentDbData2 = repository.findByDeptName(department.getDeptName());
		Department departmentDbData3 = repository.findByDeptCode(department.getDeptCode());
		Department departmentdb = repository.findById(deptId).get();

		if (departmentdb == null) {
			return new Result("E100", "Data Not exist", "");
		}
		if (!(department.getDeptId().equals(deptId))) {
			return new Result("E100", "Department Id is not matching", "");
		}

		if (Objects.nonNull(department.getDeptName()) && !"".equalsIgnoreCase(department.getDeptName())) // if null and empty data then skip data
		{
			departmentdb.setDeptName(department.getDeptName());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(department.getDeptCode()) && !"".equalsIgnoreCase(department.getDeptCode())) {
			departmentdb.setDeptCode(department.getDeptCode());// if non null and not blank then we are setting the data
		}

		if (department.getDeptId().length() != 0) {
			if (department.getDeptId().length() >= 4) {
				Result result1 = new Result("E100", "Invalid: Department Id Length is Big", "Check ID Length");
				return result1;
			}
		} else {
			Result result1 = new Result("E100", "Department Id cannot be empty", "Check ID");
			return result1;
		}

		Result resultMand = validationMandatory(department);
		if (resultMand != null) {
			return resultMand;
		}
		if (departmentDbData2 == null) {
			if (departmentDbData3 == null) {
				result = new Result("I100", "Department details Updated", departmentdb);
				repository.save(departmentdb);
				return result;
			}
			return new Result("E100", "Department code is already registered", "");
		}
		return new Result("E100", "Department Name is already registered", "");
	}

}
