package com.zkteco.task.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Designation;
import com.zkteco.task.entity.Result;
import com.zkteco.task.repository.DesignationRepository;

import jakarta.validation.Valid;

@Service
public class DesignationServiceImpl implements DesignationService {

	@Autowired
	private DesignationRepository repository;

	public Result validationMandatory(Designation designation) {
		String name = designation.getDesigName();
		String code = designation.getDesigCode();

		if (!name.isEmpty()) {
			if (name.length() >= 50) {
				return new Result("E100", "Designation Name Too Lengthy", "");
			}
		} else {
			return new Result("E100", "Designation Name cannot be empty", "");
		}
		if (!code.isEmpty()) {
			if (code.length() >= 30) {
				return new Result("E100", "Designation code Too Lengthy", "");
			}
		} else {
			return new Result("E100", "Designation code cannot be empty", "");
		}
		return null;

	}

	public Result validation(Designation designation) {
		Optional<Designation> designationDbData = repository.findById(designation.getDesigId());
		Designation designationDbData1 = repository.findByDesigName(designation.getDesigName());
		Designation designationDbData2 = repository.findByDesigCode(designation.getDesigCode());
		Designation designationResponse = new Designation();

		if (designation.getDesigId().length() != 0) {
			if (designation.getDesigId().length() >= 4) {
				Result result = new Result("E100", "Invalid: Designation Id Length is Big", "Check ID Length");
				return result;
			}
		} else {
			Result result = new Result("E100", "Designation Id cannot be empty", "Check ID");
			return result;
		}
		Result resultMand = validationMandatory(designation);
		if (resultMand != null)
			return resultMand;

		if (designationDbData.isEmpty()) {
			if (designationDbData1 == null) {
				if (designationDbData2 == null) {
					designationResponse = repository.save(designation);
					Result result = new Result("I100", "Designation Data Saved in the DataBase", designationResponse);
					return result;
				}
				return new Result("E100", "Designation code is already registered", "");
			}
			return new Result("E100", "Designation Name is already registered", "");
		}
		return new Result("E100", "This Designation Is Already Registered", "");

	}
	@Override
	public Result saveDepartment(@Valid Designation designation) {
		if (designation != null) {
			Result result1 = validation(designation);
			return result1;
		}
		return new Result("E100", "Please send Designation details", "");
	}

	@Override
	public List<Result> saveAllData(@Valid List<Designation> designation) {
		List<Result> results = new ArrayList<>();
		for (Designation designationData : designation) {
			Result result1 = validation(designationData);
			results.add(result1);
		}
		return results;
	}

	@Override
	public List<Designation> fetchAllData() {
		return repository.findAll();
	}

	@Override
	public Result fetchById(String desigId) {
		Result result = new Result();
		Optional<Designation> designation = repository.findById(desigId);
		// .orElseThrow(()->new ResourceNotFoundException("User Not found for this is id
		// "+userId));
		if (!designation.isEmpty()) {
			result.setCode("I100");
			result.setData(designation.get());
			result.setMessage("Success");
		} else {
			result.setCode("E100");
			result.setMessage("Designation not exist");
		}
		return result;
	}

	@Override
	public Result deleteById(String desigId) {
		Result result = new Result();
		Optional<Designation> designation = repository.findById(desigId);
		if (!designation.isEmpty()) {
			result.setCode("");
			result.setData("");
			result.setMessage("Deleted Succesfully");
			repository.deleteById(desigId);
		} else {
			result.setCode("E100");
			result.setMessage("data not exist");
		}
		return result;
	}

	@Override
	public Result updateById(String desigId, Designation designation) {
		Result result;
		Designation designationDbData2 = repository.findByDesigName(designation.getDesigName());
		Designation designationDbData3 = repository.findByDesigCode(designation.getDesigCode());
		Designation designationdb = repository.findById(desigId).get();

		if (designationdb == null) {
			return new Result("E100", "Data Not exist", "");
		}
		if (!(designation.getDesigId().equals(desigId))) {
			return new Result("E100", "Designation Id is not matching", "");
		}

		if (Objects.nonNull(designation.getDesigName()) && !"".equalsIgnoreCase(designation.getDesigName())) // if null and empty data then skip data
		{
			designationdb.setDesigName(designation.getDesigName());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(designation.getDesigCode()) && !"".equalsIgnoreCase(designation.getDesigCode())) {
			designationdb.setDesigCode(designation.getDesigCode());// if non null and not blank then we are setting the data
		}

		if (designation.getDesigId().length() != 0) {
			if (designation.getDesigId().length() >= 4) {
				Result result1 = new Result("E100", "Invalid: Designation Id Length is Big", "Check ID Length");
				return result1;
			}
		} else {
			Result result1 = new Result("E100", "Designation Id cannot be empty", "Check ID");
			return result1;
		}

		Result resultMand = validationMandatory(designation);
		if (resultMand != null) {
			return resultMand;
		}
		if (designationDbData2 == null) {
			if (designationDbData3 == null) {
				result = new Result("I100", "Department details Updated", designationdb);
				repository.save(designationdb);
				return result;
			}
			return new Result("E100", "Designation code is already registered", "");
		}
		return new Result("E100", "Designation Name is already registered", "");
	}

}
