package com.zkteco.task.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Designation;
import com.zkteco.task.entity.Result;

import jakarta.validation.Valid;

@Service
public interface DesignationService {

	Result saveDepartment(@Valid Designation designation);

	List<Result> saveAllData(@Valid List<Designation> designation);

	List<Designation> fetchAllData();

	Result fetchById(String desigId);

	Result deleteById(String desigId);

	Result updateById(String desigId, Designation designation);

}
