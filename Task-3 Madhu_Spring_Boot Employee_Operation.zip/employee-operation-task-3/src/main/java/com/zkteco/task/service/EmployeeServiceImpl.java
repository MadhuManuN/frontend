package com.zkteco.task.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Result;
import com.zkteco.task.entity.Department;
import com.zkteco.task.entity.Designation;
import com.zkteco.task.entity.Employee;
import com.zkteco.task.exception.ResourceNotFoundException;
import com.zkteco.task.repository.DepartmentRepository;
import com.zkteco.task.repository.DesignationRepository;
import com.zkteco.task.repository.EmployeeRepository;

import jakarta.validation.Valid;


@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository repository;
	@Autowired
	private DepartmentRepository deptRepository;
	
	@Autowired
	private DesignationRepository desigRepository;

	public Result validationMandatory(Employee employee) {
		String firstName = employee.getFirstName();
		String email = employee.getEmployeeEmailId();
		String phone = employee.getPhoneNumber();
		String password = employee.getPassword();
		if (!firstName.isEmpty()) {
			if (firstName.length() >= 10) {
				return new Result("E100","User Name Too Lengthy", "");
			}
		} else {
			return new Result("E100","Employee Name cannot be empty", "");
		}
		if (employee.getLastName().length() >= 6) {
			return new Result("E100","User Last Name is Too Lengthy", "check length");
		}
		if (employee.getGender().length() > 2) {
			return new Result("E100","Enter gender in 1 character", "check length");
		}
		if (!email.isEmpty()) {
			if (!email.contains(".") && !email.contains("@")) {
				Result result = new Result("E100","Email Should contain Dot '.' and '@' Symbol", "Invalid");
				return result;
			} else if (!email.contains("@")) {
				Result result = new Result("E100","Email Should contain '@' Symbol", "");
				return result;
			} else if (!email.contains(".")) {
				Result result = new Result("E100","Email Should contain Dot '.'", "");
				return result;
			}
		} else {
			Result result = new Result("E100","Email cannot be empty", "");
			return result;
		}

		if (!phone.isEmpty()) {
			String[] arr = phone.split("-", 2);
			if (phone.length() > 14) {
				Result result = new Result("E100","Invalid Phone Number", "");
				return result;
			} else if (!phone.contains("-") && !phone.contains("+")) {
				Result result = new Result("E100","Invalid Phone Number '+' and '-' is missing", "");
				return result;
			} else if (!phone.contains("+")) {
				Result result = new Result("E100","Invalid Phone Number '+' is missing", "");
				return result;
			} else if (!phone.contains("-")) {
				Result result = new Result("E100","Invalid Phone Number '-' is missing", "");
				return result;
			}

			if (!(arr[1].length() == 10)) {
				Result result = new Result("E100","Phone number is incorrect", "");
				return result;
			} else if (!arr[0].contains("+91") && !(arr[0].length() == 3)) {
				Result result = new Result("E100","Country code is Wrong", "");
				return result;
			}
		} else {
			Result result = new Result("E100","Phone Number cannot be empty", "");
			return result;
		}

		if (!password.isEmpty()) {
			if (!(password.matches("(([a-zA-Z].*[0-9])|([0-9].*[a-zA-Z]))"))) {
				return new Result("E100","Password has invalid characters", "");
			}
			if (!(password.length() >= 8 && password.length() <= 20)) {
				return new Result("E100","Password length is invalid", "");
			} else if (!(password.matches(".*[0-9]{2,}.*"))) {
				return new Result("E100","Password should consists of atleast two Digits", "Invalid");
			} else if (!(password.matches(".*[A-Z]{1,}.*"))) {
				return new Result("E100","Password should consists of atleast One Upper Case", "Invalid");
			}
		} else {
			return new Result("E100","Password cannot be empty", "");
		}
		return null;

	}

	public Result validation(Employee employee) {
		Optional<Employee> employeeDbData = repository.findById(employee.getEmployeeId());
		Employee employeeDbData1 = repository.findByEmployeeEmailId(employee.getEmployeeEmailId());
		Employee employeeDbData2 = repository.findByphoneNumber(employee.getPhoneNumber());
		Employee employeeResponse = new Employee();

		if (employee.getEmployeeId().length() != 0) {
			if (employee.getEmployeeId().length() >= 4) {
				Result result = new Result("E100","Invalid: User Id Length is Big", "Check ID Length");
				return result;
			}
		} else {
			Result result = new Result("E100","Employee Id cannot be empty", "Check ID");
			return result;
		}
		Result resultMand = validationMandatory(employee);
		if (resultMand != null)
			return resultMand;

		if (employeeDbData.isEmpty()) {
			if (employeeDbData1 == null) {
				if (employeeDbData2 == null) {
					Department deptDb = deptRepository.findById(employee.getDepartment().getDeptId()).orElse(null);
					Designation desigDb=desigRepository.findById(employee.getDesignation().getDesigId()).orElse(null);
			        if (deptDb == null) {
			            deptDb = new Department();
			        }
			        if(desigDb==null)
			        {
			        	desigDb=new Designation();
			        }
			        employee.setDesignation(desigDb);
			        employee.setDepartment(deptDb);
					employeeResponse = repository.save(employee);
					Result result = new Result("I100","Employee Data Saved in the DataBase", employeeResponse);
					return result;
				}
				return new Result("E100","Phone Number is already registered", "");
			}
			return new Result("E100","Email Address is already registered", "");
		}
		return new Result("E100","This Employee Is Already Registered", "");

	}

	@Override
	public Result saveEmployee(@Valid Employee employee) {
		

		if (employee != null) {
			Result result1 = validation(employee);
			return result1;
		}
		return new Result("E100","Please send Employee details", "");

	}
	
	@Override
	public List<Result> saveAllData(@Valid List<Employee> employee) {
		
		List<Result> results=new ArrayList<>();
		for (Employee employeeData : employee) {
				Result result1 = validation(employeeData);
				results.add(result1);
		}
		return results;
	}

	@Override
	public List<Employee> fetchAllData() {
		return repository.findAll();
	}

	@Override
	public Result fetchById(String employeeId) throws ResourceNotFoundException {
		Result result = new Result();
		Optional<Employee> employee = repository.findById(employeeId);
		// .orElseThrow(()->new ResourceNotFoundException("User Not found for this is id
		// "+userId));
		if (!employee.isEmpty()) {
			result.setCode("I100");
			result.setData(employee.get());
			result.setMessage("Success");
		} else {
			result.setCode("E100");
			result.setMessage("Employee not exist");
		}
		return result;
	}

	@Override
	public Result fetchByEmail(String employeeEmailId) throws ResourceNotFoundException {
		Result result = new Result();
		Employee employee = repository.findByEmployeeEmailId(employeeEmailId);
		if (employee == null) {
			throw new ResourceNotFoundException("Employee Not found for this is emailId " + employeeEmailId);
		}
		else {
			result.setCode("I100");
			result.setData(employee);
			result.setMessage("Success");
		}
		return result;
	}

	@Override
	public Result fetchByPhone(String phoneNumber) throws ResourceNotFoundException {
		Result result = new Result();
		List<Employee> employeeDb = fetchAllData();
		String[] phone = phoneNumber.split("-", 2);
		for (Employee employee : employeeDb) {
			if ((employee.getPhoneNumber().split("-", 2)[1].equals(phone[1]))) {
				result.setCode("I100");
				result.setData(employee);
				result.setMessage("Success");
			} else {
				result.setCode("E100");
				result.setMessage("Employee not exist");
			}
		}
		return result;
	}

	@Override
	public Result deleteById(String employeeId) {
		Result result = new Result();
		Optional<Employee> employee = repository.findById(employeeId);
		if (!employee.isEmpty()) {
			result.setMessage("Deleted Succesfully");
			repository.deleteById(employeeId);
		} else {
			result.setCode("E100");
			result.setMessage("data not exist");
		}
		return result;

	}

	@Override
	public Result updateById(String employeeId, Employee employee) {
		Result result;
		Employee employeedb = repository.findById(employeeId).get();

		if (employeedb == null) {
			return new Result("E100","Data Not exist", "");

		}

		if (Objects.nonNull(employee.getFirstName()) && !"".equalsIgnoreCase(employee.getFirstName())) // if null and empty data
																								// then skip that data
		{
			employeedb.setFirstName(employee.getFirstName());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(employee.getLastName()) && !"".equalsIgnoreCase(employee.getLastName())) {
			employeedb.setLastName(employee.getLastName());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(employee.getGender()) && !"".equalsIgnoreCase(employee.getGender())) {
			employeedb.setGender(employee.getGender());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(employee.getEmployeeEmailId()) && !"".equalsIgnoreCase(employee.getEmployeeEmailId())) {
			employeedb.setEmployeeEmailId(employee.getEmployeeEmailId());// if non null and not blank then we are setting the data
		}
		if (Objects.nonNull(employee.getPhoneNumber())) {
			employeedb.setPhoneNumber(employee.getPhoneNumber());
		}
		if (Objects.nonNull(employee.getDateOfBirth()) && !"".equalsIgnoreCase(employee.getDateOfBirth())) {
			employeedb.setDateOfBirth(employee.getDateOfBirth());
		}
		if (Objects.nonNull(employee.getPassword()) && !"".equalsIgnoreCase(employee.getPassword())) {
			employeedb.setPassword(employee.getPassword());
		}
		if (Objects.nonNull(employee.getCreateDate()) && !"".equalsIgnoreCase(employee.getCreateDate())) {
			employeedb.setCreateDate(employee.getCreateDate());
		}
		if (Objects.nonNull(employee.getUpdateDate()) && !"".equalsIgnoreCase(employee.getUpdateDate())) {
			employeedb.setUpdateDate(employee.getUpdateDate());
		}

		Result resultMand = validationMandatory(employee);
		if (resultMand != null) {
			return resultMand;
		}
		else {
			result=new Result("I100","Employee details Updated", employeedb);
			repository.save(employeedb);
		}
		return result;
	}

	

	public List<Employee> fetchByDate(String fromDate, String toDate) throws ResourceNotFoundException {

//		int from=Integer.parseInt(fromDate);
//		int to=Integer.parseInt(toDate);
//		List<User> userDb=repository.findAll();
//		List<User> user2=new ArrayList<>();
//		for (User userData : userDb) {
//			String[] str=userData.getCreateDate().split("/");
//			int val=Integer.parseInt(str[0]);
//			if((val>=from) && (val<=to))
//			{
//				user2.add(userData);
//			}
//		}
//		return  user2;
		if ((LocalDate.parse(fromDate)).isAfter(LocalDate.parse(toDate))) {
			throw new ResourceNotFoundException("Start Date Should be After End date");
		}
		List<Employee> employeeDb = repository.findAll();
		List<Employee> filteredEmployee = employeeDb.stream().filter(employeeDate -> {
			if ((LocalDate.parse(employeeDate.getCreateDate()).isEqual(LocalDate.parse(fromDate))
					|| LocalDate.parse(employeeDate.getCreateDate()).isAfter(LocalDate.parse(fromDate)))
					&& (LocalDate.parse(employeeDate.getCreateDate()).isEqual(LocalDate.parse(toDate))
							|| LocalDate.parse(employeeDate.getCreateDate()).isBefore(LocalDate.parse(toDate)))) {
				return true;
			}
			return false;
		}).collect(Collectors.toList());
		return filteredEmployee;

	}

}
